-- Add event management functions and triggers

-- Function to automatically add organizer as participant
CREATE OR REPLACE FUNCTION add_organizer_as_participant()
RETURNS TRIGGER AS $$
BEGIN
    -- Add organizer as confirmed participant
    INSERT INTO game_participants (
        game_id,
        player_id,
        status,
        is_ready
    ) VALUES (
        NEW.id,
        NEW.organizer_id,
        'CONFIRMED',
        true
    );

    -- Create announcement message
    INSERT INTO messages (
        game_id,
        user_id,
        content,
        type
    ) VALUES (
        NEW.id,
        NEW.organizer_id,
        'Game created by organizer',
        'ANNOUNCEMENT'
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger to add organizer when game is created
CREATE TRIGGER add_organizer_on_game_creation
    AFTER INSERT ON games
    FOR EACH ROW
    EXECUTE FUNCTION add_organizer_as_participant();

-- Function to notify participants of game changes
CREATE OR REPLACE FUNCTION notify_game_changes()
RETURNS TRIGGER AS $$
BEGIN
    -- Only proceed if there are actual changes
    IF OLD.sport_type = NEW.sport_type 
       AND OLD.date = NEW.date 
       AND OLD.time = NEW.time 
       AND OLD.venue_id = NEW.venue_id 
       AND OLD.max_players = NEW.max_players 
       AND OLD.price_per_player = NEW.price_per_player 
       AND OLD.status = NEW.status THEN
        RETURN NEW;
    END IF;

    -- Create announcement message about the changes
    INSERT INTO messages (
        game_id,
        user_id,
        content,
        type
    ) VALUES (
        NEW.id,
        NEW.organizer_id,
        CASE
            WHEN NEW.status = 'CANCELLED' THEN 'Game has been cancelled by the organizer'
            ELSE 'Game details have been updated by the organizer'
        END,
        'ANNOUNCEMENT'
    );

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger for game updates
CREATE TRIGGER notify_on_game_changes
    AFTER UPDATE ON games
    FOR EACH ROW
    EXECUTE FUNCTION notify_game_changes();

-- Function to prevent organizer removal
CREATE OR REPLACE FUNCTION prevent_organizer_removal()
RETURNS TRIGGER AS $$
BEGIN
    -- Check if trying to remove or change organizer's status
    IF EXISTS (
        SELECT 1 FROM games
        WHERE id = OLD.game_id
        AND organizer_id = OLD.player_id
    ) THEN
        RAISE EXCEPTION 'Cannot remove or modify the organizer''s participation';
    END IF;

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

-- Trigger to prevent organizer removal
CREATE TRIGGER prevent_organizer_removal
    BEFORE DELETE OR UPDATE ON game_participants
    FOR EACH ROW
    EXECUTE FUNCTION prevent_organizer_removal();

-- Update games policies to ensure organizer control
DROP POLICY IF EXISTS "Organizers can update own games" ON games;
CREATE POLICY "Organizers can update own games"
    ON games FOR UPDATE
    TO authenticated
    USING (
        organizer_id = auth.uid() OR
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'ADMIN'
        )
    )
    WITH CHECK (
        organizer_id = auth.uid() OR
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'ADMIN'
        )
    );

-- Add policy for game deletion
CREATE POLICY "Organizers can delete own games"
    ON games FOR DELETE
    TO authenticated
    USING (
        organizer_id = auth.uid() OR
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'ADMIN'
        )
    );

-- Notify PostgREST to reload schema
NOTIFY pgrst, 'reload schema';