-- Disable email confirmation requirement
UPDATE auth.config
SET email_confirmation_required = false
WHERE id = 1;

-- Update existing users to confirmed status if needed
UPDATE auth.users
SET email_confirmed_at = NOW()
WHERE email_confirmed_at IS NULL;