-- Drop existing function and trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Create improved function for handling user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  default_role user_role;
  profile_exists boolean;
  max_retries constant int := 5;
  current_try int := 0;
  backoff_interval constant float := 0.1;  -- 100ms base interval
BEGIN
  -- Retry loop for profile creation
  WHILE current_try < max_retries LOOP
    BEGIN
      -- Check if profile already exists
      SELECT EXISTS (
        SELECT 1 FROM profiles WHERE id = NEW.id
      ) INTO profile_exists;

      IF profile_exists THEN
        RETURN NEW;
      END IF;

      -- Validate and set role
      default_role := CASE 
        WHEN NEW.raw_user_meta_data->>'role' IN ('PLAYER', 'ORGANIZER', 'ADMIN') 
        THEN (NEW.raw_user_meta_data->>'role')::user_role
        ELSE 'PLAYER'::user_role
      END;

      -- Create profile with validated data
      INSERT INTO public.profiles (
        id,
        email,
        name,
        role,
        phone,
        organizer_status,
        created_at,
        updated_at
      )
      VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
        default_role,
        COALESCE(NEW.raw_user_meta_data->>'phone', ''),
        CASE 
          WHEN default_role = 'ORGANIZER' THEN 'PENDING'
          ELSE 'NOT_APPLIED'
        END,
        NOW(),
        NOW()
      );

      -- Log successful profile creation
      INSERT INTO auth.audit_log_entries (
        instance_id,
        uuid,
        event_type,
        metadata
      )
      VALUES (
        auth.uid(),
        NEW.id,
        'profile_created',
        jsonb_build_object(
          'email', NEW.email,
          'role', default_role,
          'attempt', current_try + 1
        )
      );

      RETURN NEW;
    EXCEPTION
      WHEN unique_violation THEN
        -- Another process might have created the profile, verify
        SELECT EXISTS (
          SELECT 1 FROM profiles WHERE id = NEW.id
        ) INTO profile_exists;
        
        IF profile_exists THEN
          RETURN NEW;
        END IF;
      WHEN OTHERS THEN
        -- Log error details
        INSERT INTO auth.audit_log_entries (
          instance_id,
          uuid,
          event_type,
          metadata
        )
        VALUES (
          auth.uid(),
          NEW.id,
          'profile_creation_error',
          jsonb_build_object(
            'error', SQLERRM,
            'attempt', current_try + 1
          )
        );
    END;
    
    current_try := current_try + 1;
    -- Exponential backoff with maximum delay of 1 second
    PERFORM pg_sleep(LEAST(backoff_interval * pow(2, current_try), 1.0));
  END LOOP;

  RETURN NEW;
END;
$$;

-- Create trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Create index for better performance
CREATE INDEX IF NOT EXISTS idx_profiles_id_email ON profiles(id, email);

-- Ensure proper permissions
GRANT USAGE ON SCHEMA public TO authenticated, service_role;
GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
GRANT SELECT, UPDATE ON profiles TO authenticated;