-- Add new columns to game_participants table
ALTER TABLE game_participants
ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'PENDING',
ADD COLUMN IF NOT EXISTS is_ready BOOLEAN NOT NULL DEFAULT false,
ADD CONSTRAINT proper_status CHECK (status IN ('PENDING', 'CONFIRMED', 'DECLINED', 'LEFT'));

-- Create messages table for group chat
CREATE TABLE IF NOT EXISTS messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    game_id UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES profiles(id),
    content TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'CHAT',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    CONSTRAINT proper_message_type CHECK (type IN ('CHAT', 'ANNOUNCEMENT'))
);

-- Create event reminders table
CREATE TABLE IF NOT EXISTS event_reminders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    game_id UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES profiles(id),
    reminder_time TIMESTAMP WITH TIME ZONE NOT NULL,
    is_enabled BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    UNIQUE(game_id, user_id)
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_messages_game_id ON messages(game_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);
CREATE INDEX IF NOT EXISTS idx_event_reminders_game_user ON event_reminders(game_id, user_id);

-- Enable RLS
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_reminders ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for messages
CREATE POLICY "Users can view messages for their games"
    ON messages FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM game_participants
            WHERE game_participants.game_id = messages.game_id
            AND game_participants.player_id = auth.uid()
        )
    );

CREATE POLICY "Users can insert messages for their games"
    ON messages FOR INSERT
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM game_participants
            WHERE game_participants.game_id = messages.game_id
            AND game_participants.player_id = auth.uid()
        )
    );

-- Create RLS policies for event reminders
CREATE POLICY "Users can manage their own reminders"
    ON event_reminders
    USING (user_id = auth.uid())
    WITH CHECK (user_id = auth.uid());

-- Grant permissions
GRANT SELECT, INSERT ON messages TO authenticated;
GRANT ALL ON event_reminders TO authenticated;

-- Create function to handle message creation with type validation
CREATE OR REPLACE FUNCTION handle_message_creation()
RETURNS TRIGGER AS $$
BEGIN
    -- Only allow organizers to send announcements
    IF NEW.type = 'ANNOUNCEMENT' THEN
        IF NOT EXISTS (
            SELECT 1 FROM games
            WHERE id = NEW.game_id
            AND organizer_id = NEW.user_id
        ) THEN
            RAISE EXCEPTION 'Only organizers can send announcements';
        END IF;
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for message validation
CREATE TRIGGER validate_message_before_insert
    BEFORE INSERT ON messages
    FOR EACH ROW
    EXECUTE FUNCTION handle_message_creation();