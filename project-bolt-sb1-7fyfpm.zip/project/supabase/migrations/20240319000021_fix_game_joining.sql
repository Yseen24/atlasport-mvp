-- Drop existing function if it exists
DROP FUNCTION IF EXISTS increment_players(UUID);

-- Create function to increment players count
CREATE OR REPLACE FUNCTION increment_players(game_id UUID)
RETURNS void AS $$
BEGIN
    UPDATE games
    SET current_players = current_players + 1
    WHERE id = game_id
    AND current_players < max_players;
END;
$$ LANGUAGE plpgsql;

-- Create function to handle game participant creation
CREATE OR REPLACE FUNCTION handle_game_participant_creation()
RETURNS TRIGGER AS $$
BEGIN
    -- Increment the current_players count
    UPDATE games
    SET current_players = current_players + 1
    WHERE id = NEW.game_id
    AND current_players < max_players;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for participant creation
CREATE TRIGGER on_game_participant_created
    AFTER INSERT ON game_participants
    FOR EACH ROW
    EXECUTE FUNCTION handle_game_participant_creation();

-- Grant execute permission on the function
GRANT EXECUTE ON FUNCTION increment_players(UUID) TO authenticated;