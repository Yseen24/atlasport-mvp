-- Drop existing venues table
DROP TABLE IF EXISTS venues CASCADE;

-- Create venues table with complete schema
CREATE TABLE venues (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    sports_supported TEXT[] NOT NULL DEFAULT '{}',
    facilities TEXT[] NOT NULL DEFAULT '{}',
    opening_time TIME NOT NULL,
    closing_time TIME NOT NULL,
    contact_phone TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    CONSTRAINT proper_phone CHECK (contact_phone ~* '^\+[0-9]{1,3}[0-9]{9,}$'),
    CONSTRAINT proper_status CHECK (status IN ('ACTIVE', 'INACTIVE', 'MAINTENANCE')),
    CONSTRAINT valid_times CHECK (opening_time < closing_time)
);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_venues_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER venues_updated_at
    BEFORE UPDATE ON venues
    FOR EACH ROW
    EXECUTE FUNCTION update_venues_updated_at();

-- Create indexes for better query performance
CREATE INDEX idx_venues_status ON venues(status);
CREATE INDEX idx_venues_sports ON venues USING gin(sports_supported);
CREATE INDEX idx_venues_created_at ON venues(created_at);

-- Enable RLS
ALTER TABLE venues ENABLE ROW LEVEL SECURITY;

-- Drop existing policies
DROP POLICY IF EXISTS "Venues are viewable by everyone" ON venues;
DROP POLICY IF EXISTS "Only admins can insert venues" ON venues;
DROP POLICY IF EXISTS "Only admins can update venues" ON venues;

-- Create RLS policies
CREATE POLICY "Venues are viewable by everyone"
    ON venues FOR SELECT
    USING (true);

CREATE POLICY "Only admins can insert venues"
    ON venues FOR INSERT
    TO authenticated
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'ADMIN'
        )
    );

CREATE POLICY "Only admins can update venues"
    ON venues FOR UPDATE
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'ADMIN'
        )
    );

-- Grant permissions
GRANT ALL ON venues TO service_role;
GRANT SELECT ON venues TO authenticated;
GRANT INSERT, UPDATE ON venues TO authenticated;

-- Create function to validate sports array
CREATE OR REPLACE FUNCTION validate_sports_array()
RETURNS TRIGGER AS $$
BEGIN
    IF NOT (NEW.sports_supported <@ ARRAY['Football', 'Basketball', 'Volleyball']::TEXT[]) THEN
        RAISE EXCEPTION 'Invalid sport type. Allowed values are: Football, Basketball, Volleyball';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for sports validation
CREATE TRIGGER validate_sports_before_save
    BEFORE INSERT OR UPDATE ON venues
    FOR EACH ROW
    EXECUTE FUNCTION validate_sports_array();

-- Create function to validate facilities array
CREATE OR REPLACE FUNCTION validate_facilities_array()
RETURNS TRIGGER AS $$
BEGIN
    IF NOT (NEW.facilities <@ ARRAY['changing_rooms', 'parking', 'lighting', 'spectator_seating', 'shower', 'lockbox']::TEXT[]) THEN
        RAISE EXCEPTION 'Invalid facility type';
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for facilities validation
CREATE TRIGGER validate_facilities_before_save
    BEFORE INSERT OR UPDATE ON venues
    FOR EACH ROW
    EXECUTE FUNCTION validate_facilities_array();