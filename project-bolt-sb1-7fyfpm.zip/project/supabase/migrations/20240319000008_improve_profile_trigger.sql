-- Drop existing function and trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Create improved function for handling user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  default_role user_role;
  profile_exists boolean;
  max_retries constant int := 3;
  current_try int := 0;
BEGIN
  -- Retry loop for profile creation
  WHILE current_try < max_retries LOOP
    BEGIN
      -- Check if profile already exists
      SELECT EXISTS (
        SELECT 1 FROM profiles WHERE id = NEW.id
      ) INTO profile_exists;

      IF profile_exists THEN
        RETURN NEW;
      END IF;

      -- Validate and set role
      default_role := CASE 
        WHEN NEW.raw_user_meta_data->>'role' IN ('PLAYER', 'ORGANIZER', 'ADMIN') 
        THEN (NEW.raw_user_meta_data->>'role')::user_role
        ELSE 'PLAYER'::user_role
      END;

      -- Create profile with validated data
      INSERT INTO public.profiles (
        id,
        email,
        name,
        role,
        phone,
        organizer_status,
        created_at,
        updated_at
      )
      VALUES (
        NEW.id,
        NEW.email,
        COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
        default_role,
        COALESCE(NEW.raw_user_meta_data->>'phone', ''),
        CASE 
          WHEN default_role = 'ORGANIZER' THEN 'PENDING'
          ELSE 'NOT_APPLIED'
        END,
        NOW(),
        NOW()
      );

      -- If we get here, profile was created successfully
      RETURN NEW;
    EXCEPTION
      WHEN unique_violation THEN
        -- Another process might have created the profile, check again
        IF current_try = max_retries - 1 THEN
          RAISE WARNING 'Failed to create profile after % retries', max_retries;
        END IF;
      WHEN OTHERS THEN
        IF current_try = max_retries - 1 THEN
          RAISE WARNING 'Error creating profile: %', SQLERRM;
        END IF;
    END;
    
    current_try := current_try + 1;
    -- Small delay between retries
    PERFORM pg_sleep(0.1);
  END LOOP;

  RETURN NEW;
END;
$$;

-- Create trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();