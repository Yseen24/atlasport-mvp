-- Add is_ready column to game_participants
ALTER TABLE game_participants
ADD COLUMN IF NOT EXISTS is_ready BOOLEAN NOT NULL DEFAULT false;

-- Notify PostgREST to reload schema
NOTIFY pgrst, 'reload schema';