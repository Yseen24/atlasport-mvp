-- Update venues table schema
ALTER TABLE venues
ADD COLUMN IF NOT EXISTS opening_time TIME,
ADD COLUMN IF NOT EXISTS closing_time TIME,
ADD COLUMN IF NOT EXISTS contact_phone TEXT;

-- Add constraints
ALTER TABLE venues
ADD CONSTRAINT proper_contact_phone 
CHECK (contact_phone ~* '^\+?[0-9\s-]+$');

-- Update trigger for updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Recreate trigger
DROP TRIGGER IF EXISTS update_venues_updated_at ON venues;
CREATE TRIGGER update_venues_updated_at
    BEFORE UPDATE ON venues
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- Recreate indexes
DROP INDEX IF EXISTS idx_venues_status;
DROP INDEX IF EXISTS idx_venues_sports;

CREATE INDEX idx_venues_status ON venues(status);
CREATE INDEX idx_venues_sports ON venues USING gin(sports_supported);

-- Update RLS policies
ALTER TABLE venues ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Venues are viewable by everyone" ON venues;
DROP POLICY IF EXISTS "Only admins can insert venues" ON venues;
DROP POLICY IF EXISTS "Only admins can update venues" ON venues;

CREATE POLICY "Venues are viewable by everyone"
    ON venues FOR SELECT
    USING (true);

CREATE POLICY "Only admins can insert venues"
    ON venues FOR INSERT
    TO authenticated
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'ADMIN'
        )
    );

CREATE POLICY "Only admins can update venues"
    ON venues FOR UPDATE
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'ADMIN'
        )
    );

-- Grant permissions
GRANT ALL ON venues TO service_role;
GRANT SELECT ON venues TO authenticated;
GRANT INSERT, UPDATE ON venues TO authenticated;