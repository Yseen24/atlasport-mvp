-- Drop existing policies
DROP POLICY IF EXISTS "Enable insert for organizers" ON games;

-- Create new policy that checks organizer approval status
CREATE POLICY "Enable insert for approved organizers only"
    ON games FOR INSERT
    TO authenticated
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND UPPER(profiles.role) IN ('ORGANIZER', 'ADMIN')
            AND (
                UPPER(profiles.role) = 'ADMIN' OR
                profiles.organizer_status = 'APPROVED'
            )
        )
    );

-- Create function to validate organizer status
CREATE OR REPLACE FUNCTION check_organizer_status()
RETURNS TRIGGER AS $$
BEGIN
    -- Check if user is an approved organizer or admin
    IF NOT EXISTS (
        SELECT 1 FROM profiles
        WHERE id = NEW.organizer_id
        AND UPPER(role) IN ('ORGANIZER', 'ADMIN')
        AND (
            UPPER(role) = 'ADMIN' OR
            organizer_status = 'APPROVED'
        )
    ) THEN
        RAISE EXCEPTION 'Only approved organizers can create events';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to enforce organizer status check
DROP TRIGGER IF EXISTS check_organizer_status_trigger ON games;
CREATE TRIGGER check_organizer_status_trigger
    BEFORE INSERT ON games
    FOR EACH ROW
    EXECUTE FUNCTION check_organizer_status();

-- Notify PostgREST to reload schema
NOTIFY pgrst, 'reload schema';