-- Drop existing venues table and related objects
DROP TABLE IF EXISTS venues CASCADE;
DROP FUNCTION IF EXISTS update_venues_updated_at CASCADE;
DROP FUNCTION IF EXISTS validate_sports_array CASCADE;
DROP FUNCTION IF EXISTS validate_facilities_array CASCADE;

-- Create venues table with complete schema
CREATE TABLE venues (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    sports_supported TEXT[] NOT NULL DEFAULT '{}',
    facilities TEXT[] NOT NULL DEFAULT '{}',
    opening_time TIME NOT NULL,
    closing_time TIME NOT NULL,
    contact_phone TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    CONSTRAINT proper_phone CHECK (contact_phone ~* '^\+[0-9]{1,3}[0-9]{9,}$'),
    CONSTRAINT proper_status CHECK (status IN ('ACTIVE', 'INACTIVE', 'MAINTENANCE')),
    CONSTRAINT valid_times CHECK (opening_time < closing_time)
);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_venues_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER venues_updated_at
    BEFORE UPDATE ON venues
    FOR EACH ROW
    EXECUTE FUNCTION update_venues_updated_at();

-- Create indexes
CREATE INDEX idx_venues_status ON venues(status);
CREATE INDEX idx_venues_sports ON venues USING gin(sports_supported);
CREATE INDEX idx_venues_created_at ON venues(created_at);

-- Enable RLS
ALTER TABLE venues ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Enable read access for all users"
    ON venues FOR SELECT
    TO authenticated, anon
    USING (true);

CREATE POLICY "Enable insert for admin users only"
    ON venues FOR INSERT
    TO authenticated
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND UPPER(profiles.role) = 'ADMIN'
        )
    );

CREATE POLICY "Enable update for admin users only"
    ON venues FOR UPDATE
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND UPPER(profiles.role) = 'ADMIN'
        )
    );

-- Grant permissions
GRANT ALL ON venues TO service_role;
GRANT SELECT, INSERT, UPDATE ON venues TO authenticated;
GRANT SELECT ON venues TO anon;

-- Create function to handle venue creation
CREATE OR REPLACE FUNCTION handle_venue_creation()
RETURNS TRIGGER AS $$
BEGIN
    -- Validate sports array
    IF NOT (NEW.sports_supported <@ ARRAY['Football', 'Basketball', 'Volleyball']::TEXT[]) THEN
        RAISE EXCEPTION 'Invalid sport type. Allowed values are: Football, Basketball, Volleyball';
    END IF;

    -- Validate facilities array
    IF NOT (NEW.facilities <@ ARRAY['changing_rooms', 'parking', 'lighting', 'spectator_seating', 'shower', 'lockbox']::TEXT[]) THEN
        RAISE EXCEPTION 'Invalid facility type';
    END IF;

    -- Set created_at and updated_at
    NEW.created_at = CURRENT_TIMESTAMP;
    NEW.updated_at = CURRENT_TIMESTAMP;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for venue validation
CREATE TRIGGER validate_venue_before_save
    BEFORE INSERT OR UPDATE ON venues
    FOR EACH ROW
    EXECUTE FUNCTION handle_venue_creation();