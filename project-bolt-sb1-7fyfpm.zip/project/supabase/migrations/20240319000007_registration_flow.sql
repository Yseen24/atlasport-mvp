-- Drop existing function and trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
DROP FUNCTION IF EXISTS public.handle_new_user();

-- Create a more robust function for handling user creation
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  default_role user_role;
  profile_exists boolean;
BEGIN
  -- Check if profile already exists to prevent duplicates
  SELECT EXISTS (
    SELECT 1 FROM profiles WHERE id = NEW.id
  ) INTO profile_exists;

  IF profile_exists THEN
    RETURN NEW;
  END IF;

  -- Validate and set role
  default_role := CASE 
    WHEN NEW.raw_user_meta_data->>'role' IN ('PLAYER', 'ORGANIZER', 'ADMIN') 
    THEN (NEW.raw_user_meta_data->>'role')::user_role
    ELSE 'PLAYER'::user_role
  END;

  -- Create profile with validated data
  INSERT INTO public.profiles (
    id,
    email,
    name,
    role,
    phone,
    organizer_status,
    created_at,
    updated_at
  )
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    default_role,
    COALESCE(NEW.raw_user_meta_data->>'phone', ''),
    CASE 
      WHEN default_role = 'ORGANIZER' THEN 'PENDING'
      ELSE 'NOT_APPLIED'
    END,
    NOW(),
    NOW()
  );

  -- Create audit log entry
  INSERT INTO auth.audit_log_entries (
    instance_id,
    uuid,
    event_type,
    metadata
  )
  VALUES (
    auth.uid(),
    NEW.id,
    'profile_created',
    jsonb_build_object(
      'email', NEW.email,
      'role', default_role
    )
  );

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error details to auth.audit_log_entries
    INSERT INTO auth.audit_log_entries (
      instance_id,
      uuid,
      event_type,
      metadata
    )
    VALUES (
      auth.uid(),
      NEW.id,
      'profile_creation_error',
      jsonb_build_object(
        'error', SQLERRM,
        'email', NEW.email
      )
    );
    RAISE WARNING 'Error creating profile for user %: %', NEW.id, SQLERRM;
    RETURN NEW;
END;
$$;

-- Create trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_profiles_email_lower ON profiles (lower(email));
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
CREATE INDEX IF NOT EXISTS idx_profiles_organizer_status ON profiles(organizer_status);

-- Update RLS policies
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- Drop existing policies
DROP POLICY IF EXISTS "Enable insert for service role only" ON profiles;
DROP POLICY IF EXISTS "Enable select for everyone" ON profiles;
DROP POLICY IF EXISTS "Enable update for users based on id" ON profiles;

-- Create new policies with proper permissions
CREATE POLICY "Service role can manage profiles"
  ON profiles
  TO service_role
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Users can view all profiles"
  ON profiles FOR SELECT
  TO authenticated, anon
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO authenticated, anon, service_role;
GRANT ALL ON ALL TABLES IN SCHEMA public TO authenticated, service_role;
GRANT ALL ON ALL SEQUENCES IN SCHEMA public TO authenticated, service_role;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO anon;