-- Drop and recreate participant_status enum with correct values
DROP TYPE IF EXISTS participant_status CASCADE;
CREATE TYPE participant_status AS ENUM ('PENDING', 'CONFIRMED', 'DECLINED', 'LEFT');

-- Recreate game_participants table with correct enum type
ALTER TABLE game_participants 
ALTER COLUMN status TYPE participant_status 
USING status::participant_status;

-- Update join_game function to use correct enum values
CREATE OR REPLACE FUNCTION join_game(p_game_id UUID, p_player_id UUID)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_current_players INT;
    v_max_players INT;
    v_user_role TEXT;
BEGIN
    -- Check user role
    SELECT role INTO v_user_role
    FROM profiles
    WHERE id = p_player_id;

    -- Only players can join games
    IF v_user_role != 'PLAYER' THEN
        RETURN json_build_object('error', 'Only players can join games');
    END IF;

    -- Check if player has already joined
    IF EXISTS (
        SELECT 1 FROM game_participants 
        WHERE game_id = p_game_id AND player_id = p_player_id
    ) THEN
        RETURN json_build_object('error', 'You have already joined this game');
    END IF;

    -- Get game details with lock
    SELECT current_players, max_players 
    INTO v_current_players, v_max_players
    FROM games 
    WHERE id = p_game_id
    FOR UPDATE;

    -- Check if game is full
    IF v_current_players >= v_max_players THEN
        RETURN json_build_object('error', 'This game is full');
    END IF;

    -- Create participant entry and update count atomically
    BEGIN
        INSERT INTO game_participants (
            game_id,
            player_id,
            status,
            is_ready
        ) VALUES (
            p_game_id,
            p_player_id,
            'PENDING'::participant_status,
            false
        );

        UPDATE games 
        SET current_players = current_players + 1
        WHERE id = p_game_id;

        RETURN json_build_object(
            'success', true,
            'message', 'Successfully joined game'
        );
    EXCEPTION 
        WHEN unique_violation THEN
            RETURN json_build_object('error', 'You have already joined this game');
        WHEN OTHERS THEN
            RAISE;
    END;
END;
$$;

-- Notify PostgREST to reload schema
NOTIFY pgrst, 'reload schema';