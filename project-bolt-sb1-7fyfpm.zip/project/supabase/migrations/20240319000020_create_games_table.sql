-- Drop existing games table if it exists
DROP TABLE IF EXISTS games CASCADE;

-- Create games table with complete schema
CREATE TABLE games (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sport_type TEXT NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    venue_id UUID NOT NULL REFERENCES venues(id),
    organizer_id UUID NOT NULL REFERENCES profiles(id),
    max_players INTEGER NOT NULL,
    current_players INTEGER NOT NULL DEFAULT 0,
    price_per_player DECIMAL(10,2) NOT NULL,
    status TEXT NOT NULL DEFAULT 'UPCOMING',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    CONSTRAINT valid_sport_type CHECK (sport_type IN ('Football', 'Basketball', 'Volleyball')),
    CONSTRAINT valid_status CHECK (status IN ('UPCOMING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED')),
    CONSTRAINT valid_players CHECK (current_players <= max_players),
    CONSTRAINT valid_max_players CHECK (max_players BETWEEN 2 AND 30),
    CONSTRAINT valid_price CHECK (price_per_player >= 0)
);

-- Create updated_at trigger
CREATE OR REPLACE FUNCTION update_games_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER games_updated_at
    BEFORE UPDATE ON games
    FOR EACH ROW
    EXECUTE FUNCTION update_games_updated_at();

-- Create indexes
CREATE INDEX idx_games_status ON games(status);
CREATE INDEX idx_games_date ON games(date);
CREATE INDEX idx_games_venue_id ON games(venue_id);
CREATE INDEX idx_games_organizer_id ON games(organizer_id);

-- Enable RLS
ALTER TABLE games ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Enable read access for all users"
    ON games FOR SELECT
    TO authenticated, anon
    USING (true);

CREATE POLICY "Enable insert for organizers"
    ON games FOR INSERT
    TO authenticated
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND UPPER(profiles.role) IN ('ORGANIZER', 'ADMIN')
            AND profiles.organizer_status = 'APPROVED'
        )
    );

CREATE POLICY "Enable update for game organizers"
    ON games FOR UPDATE
    TO authenticated
    USING (
        organizer_id = auth.uid() OR
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND UPPER(profiles.role) = 'ADMIN'
        )
    );

-- Grant permissions
GRANT ALL ON games TO service_role;
GRANT SELECT, INSERT, UPDATE ON games TO authenticated;
GRANT SELECT ON games TO anon;

-- Create function to handle game creation
CREATE OR REPLACE FUNCTION handle_game_creation()
RETURNS TRIGGER AS $$
BEGIN
    -- Set created_at and updated_at
    NEW.created_at = CURRENT_TIMESTAMP;
    NEW.updated_at = CURRENT_TIMESTAMP;

    -- Ensure current_players starts at 0
    NEW.current_players = 0;

    -- Set default status if not provided
    IF NEW.status IS NULL THEN
        NEW.status = 'UPCOMING';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for game creation
CREATE TRIGGER handle_game_creation
    BEFORE INSERT ON games
    FOR EACH ROW
    EXECUTE FUNCTION handle_game_creation();

-- Create function to increment players count
CREATE OR REPLACE FUNCTION increment_game_players()
RETURNS TRIGGER AS $$
BEGIN
    UPDATE games
    SET current_players = current_players + 1
    WHERE id = NEW.game_id
    AND current_players < max_players;
    
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to update player count when someone joins
CREATE TRIGGER increment_players_on_join
    AFTER INSERT ON game_participants
    FOR EACH ROW
    EXECUTE FUNCTION increment_game_players();