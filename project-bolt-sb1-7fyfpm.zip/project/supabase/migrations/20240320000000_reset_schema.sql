-- Drop existing tables if they exist
DROP TABLE IF EXISTS event_reminders CASCADE;
DROP TABLE IF EXISTS messages CASCADE;
DROP TABLE IF EXISTS game_participants CASCADE;
DROP TABLE IF EXISTS games CASCADE;
DROP TABLE IF EXISTS venues CASCADE;
DROP TABLE IF EXISTS profiles CASCADE;

-- Create ENUM types
CREATE TYPE user_role AS ENUM ('PLAYER', 'ORGANIZER', 'ADMIN');
CREATE TYPE game_status AS ENUM ('UPCOMING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED');
CREATE TYPE participant_status AS ENUM ('PENDING', 'CONFIRMED', 'DECLINED', 'LEFT');
CREATE TYPE message_type AS ENUM ('CHAT', 'ANNOUNCEMENT');

-- Create profiles table
CREATE TABLE profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id),
    email TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    role user_role NOT NULL DEFAULT 'PLAYER',
    phone TEXT NOT NULL,
    organizer_status TEXT NOT NULL DEFAULT 'NOT_APPLIED',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    CONSTRAINT proper_email CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
    CONSTRAINT proper_phone CHECK (phone ~* '^\+[0-9]{6,15}$')
);

-- Create venues table
CREATE TABLE venues (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    sports_supported TEXT[] NOT NULL,
    facilities TEXT[] NOT NULL DEFAULT '{}',
    opening_time TIME NOT NULL,
    closing_time TIME NOT NULL,
    contact_phone TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    CONSTRAINT proper_phone CHECK (contact_phone ~* '^\+[0-9]{6,15}$')
);

-- Create games table
CREATE TABLE games (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sport_type TEXT NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    venue_id UUID NOT NULL REFERENCES venues(id),
    organizer_id UUID NOT NULL REFERENCES profiles(id),
    max_players INTEGER NOT NULL,
    current_players INTEGER NOT NULL DEFAULT 0,
    price_per_player DECIMAL(10,2) NOT NULL,
    status game_status NOT NULL DEFAULT 'UPCOMING',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    CONSTRAINT valid_players CHECK (current_players <= max_players),
    CONSTRAINT valid_max_players CHECK (max_players BETWEEN 2 AND 30),
    CONSTRAINT valid_price CHECK (price_per_player >= 0)
);

-- Create game_participants table
CREATE TABLE game_participants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    game_id UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
    player_id UUID NOT NULL REFERENCES profiles(id),
    status participant_status NOT NULL DEFAULT 'PENDING',
    is_ready BOOLEAN NOT NULL DEFAULT false,
    joined_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    UNIQUE(game_id, player_id)
);

-- Create messages table
CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    game_id UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES profiles(id),
    content TEXT NOT NULL,
    type message_type NOT NULL DEFAULT 'CHAT',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Create event_reminders table
CREATE TABLE event_reminders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    game_id UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES profiles(id),
    reminder_time TIMESTAMP WITH TIME ZONE NOT NULL,
    is_enabled BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    UNIQUE(game_id, user_id)
);

-- Create indexes
CREATE INDEX idx_profiles_email ON profiles(email);
CREATE INDEX idx_profiles_role ON profiles(role);
CREATE INDEX idx_venues_status ON venues(status);
CREATE INDEX idx_venues_sports ON venues USING gin(sports_supported);
CREATE INDEX idx_games_status ON games(status);
CREATE INDEX idx_games_date ON games(date);
CREATE INDEX idx_game_participants_game_id ON game_participants(game_id);
CREATE INDEX idx_game_participants_player_id ON game_participants(player_id);
CREATE INDEX idx_messages_game_id ON messages(game_id);
CREATE INDEX idx_messages_created_at ON messages(created_at);
CREATE INDEX idx_event_reminders_game_user ON event_reminders(game_id, user_id);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE venues ENABLE ROW LEVEL SECURITY;
ALTER TABLE games ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE event_reminders ENABLE ROW LEVEL SECURITY;

-- Create RLS Policies

-- Profiles policies
CREATE POLICY "Users can view all profiles"
    ON profiles FOR SELECT
    TO authenticated, anon
    USING (true);

CREATE POLICY "Users can update own profile"
    ON profiles FOR UPDATE
    TO authenticated
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);

-- Venues policies
CREATE POLICY "Anyone can view venues"
    ON venues FOR SELECT
    TO authenticated, anon
    USING (true);

CREATE POLICY "Only admins can manage venues"
    ON venues
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'ADMIN'
        )
    );

-- Games policies
CREATE POLICY "Anyone can view games"
    ON games FOR SELECT
    TO authenticated, anon
    USING (true);

CREATE POLICY "Organizers can create games"
    ON games FOR INSERT
    TO authenticated
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role IN ('ORGANIZER', 'ADMIN')
            AND (profiles.role = 'ADMIN' OR profiles.organizer_status = 'APPROVED')
        )
    );

CREATE POLICY "Organizers can update own games"
    ON games FOR UPDATE
    TO authenticated
    USING (
        organizer_id = auth.uid() OR
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'ADMIN'
        )
    );

-- Game participants policies
CREATE POLICY "Anyone can view participants"
    ON game_participants FOR SELECT
    TO authenticated, anon
    USING (true);

CREATE POLICY "Users can manage own participation"
    ON game_participants
    TO authenticated
    USING (player_id = auth.uid())
    WITH CHECK (player_id = auth.uid());

-- Messages policies
CREATE POLICY "Game participants can view messages"
    ON messages FOR SELECT
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM game_participants
            WHERE game_participants.game_id = messages.game_id
            AND game_participants.player_id = auth.uid()
        ) OR
        EXISTS (
            SELECT 1 FROM games
            WHERE games.id = messages.game_id
            AND games.organizer_id = auth.uid()
        )
    );

CREATE POLICY "Game participants can send messages"
    ON messages FOR INSERT
    TO authenticated
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM game_participants
            WHERE game_participants.game_id = messages.game_id
            AND game_participants.player_id = auth.uid()
        ) OR
        EXISTS (
            SELECT 1 FROM games
            WHERE games.id = messages.game_id
            AND games.organizer_id = auth.uid()
        )
    );

-- Event reminders policies
CREATE POLICY "Users can manage own reminders"
    ON event_reminders
    TO authenticated
    USING (user_id = auth.uid())
    WITH CHECK (user_id = auth.uid());

-- Create join_game function
CREATE OR REPLACE FUNCTION join_game(p_game_id UUID, p_player_id UUID)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_current_players INT;
    v_max_players INT;
BEGIN
    -- Check if player has already joined
    IF EXISTS (
        SELECT 1 FROM game_participants 
        WHERE game_id = p_game_id AND player_id = p_player_id
    ) THEN
        RETURN json_build_object('error', 'You have already joined this game');
    END IF;

    -- Get game details with lock
    SELECT current_players, max_players 
    INTO v_current_players, v_max_players
    FROM games 
    WHERE id = p_game_id
    FOR UPDATE;

    -- Check if game is full
    IF v_current_players >= v_max_players THEN
        RETURN json_build_object('error', 'This game is full');
    END IF;

    -- Create participant entry and update count atomically
    BEGIN
        INSERT INTO game_participants (
            game_id,
            player_id,
            status,
            is_ready
        ) VALUES (
            p_game_id,
            p_player_id,
            'PENDING',
            false
        );

        UPDATE games 
        SET current_players = current_players + 1
        WHERE id = p_game_id;

        RETURN json_build_object(
            'success', true,
            'message', 'Successfully joined game'
        );
    EXCEPTION 
        WHEN unique_violation THEN
            RETURN json_build_object('error', 'You have already joined this game');
        WHEN OTHERS THEN
            RAISE;
    END;
END;
$$;

-- Grant necessary permissions
GRANT USAGE ON SCHEMA public TO authenticated, anon, service_role;
GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
GRANT SELECT, UPDATE ON profiles TO authenticated;
GRANT SELECT ON venues TO authenticated;
GRANT SELECT, INSERT ON games TO authenticated;
GRANT ALL ON game_participants TO authenticated;
GRANT ALL ON messages TO authenticated;
GRANT ALL ON event_reminders TO authenticated;
GRANT EXECUTE ON FUNCTION join_game TO authenticated;

-- Disable email confirmation requirement
UPDATE auth.config
SET email_confirmation_required = false
WHERE id = 1;