-- Drop existing function and policies
DROP FUNCTION IF EXISTS join_game CASCADE;
DROP POLICY IF EXISTS "Only players can join games" ON game_participants;
DROP POLICY IF EXISTS "Organizers auto-join own games" ON game_participants;

-- Create stricter join_game function
CREATE OR REPLACE FUNCTION join_game(p_game_id UUID, p_player_id UUID)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_current_players INT;
    v_max_players INT;
    v_user_role TEXT;
    v_is_organizer_game BOOLEAN;
BEGIN
    -- Check user role and get organizer status
    SELECT 
        role,
        EXISTS (
            SELECT 1 FROM games 
            WHERE id = p_game_id 
            AND organizer_id = p_player_id
        ) INTO v_user_role, v_is_organizer_game
    FROM profiles
    WHERE id = p_player_id;

    -- Strict role checking
    IF v_user_role = 'ORGANIZER' THEN
        RETURN json_build_object('error', 'Organizers cannot join games. They can only manage their own games.');
    END IF;

    IF v_user_role != 'PLAYER' THEN
        RETURN json_build_object('error', 'Only players can join games');
    END IF;

    -- Check if player has already joined
    IF EXISTS (
        SELECT 1 FROM game_participants 
        WHERE game_id = p_game_id AND player_id = p_player_id
    ) THEN
        RETURN json_build_object('error', 'You have already joined this game');
    END IF;

    -- Get game details with lock
    SELECT current_players, max_players 
    INTO v_current_players, v_max_players
    FROM games 
    WHERE id = p_game_id
    FOR UPDATE;

    -- Check if game exists
    IF NOT FOUND THEN
        RETURN json_build_object('error', 'Game not found');
    END IF;

    -- Check if game is full
    IF v_current_players >= v_max_players THEN
        RETURN json_build_object('error', 'This game is full');
    END IF;

    -- Create participant entry and update count atomically
    BEGIN
        INSERT INTO game_participants (
            game_id,
            player_id,
            status,
            is_ready
        ) VALUES (
            p_game_id,
            p_player_id,
            'PENDING',
            false
        );

        UPDATE games 
        SET current_players = current_players + 1
        WHERE id = p_game_id;

        RETURN json_build_object(
            'success', true,
            'message', 'Successfully joined game'
        );
    EXCEPTION 
        WHEN unique_violation THEN
            RETURN json_build_object('error', 'You have already joined this game');
        WHEN OTHERS THEN
            RAISE;
    END;
END;
$$;

-- Create strict RLS policies
CREATE POLICY "Only players can join games"
    ON game_participants FOR INSERT
    TO authenticated
    WITH CHECK (
        -- Must be a player
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'PLAYER'
        )
        AND
        -- Must be joining as themselves
        player_id = auth.uid()
        AND
        -- Cannot join if they're an organizer of any game
        NOT EXISTS (
            SELECT 1 FROM games
            WHERE games.organizer_id = auth.uid()
        )
    );

-- Separate policy for organizer auto-participation
CREATE POLICY "Organizers can only participate in own games"
    ON game_participants FOR INSERT
    TO authenticated
    WITH CHECK (
        -- Must be an organizer
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'ORGANIZER'
        )
        AND
        -- Must be their own game
        EXISTS (
            SELECT 1 FROM games
            WHERE games.id = game_id
            AND games.organizer_id = auth.uid()
        )
        AND
        -- Must be joining as themselves
        player_id = auth.uid()
    );

-- Notify PostgREST to reload schema
NOTIFY pgrst, 'reload schema';