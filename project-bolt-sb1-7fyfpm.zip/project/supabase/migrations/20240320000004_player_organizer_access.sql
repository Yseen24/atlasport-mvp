-- Drop existing policies
DROP POLICY IF EXISTS "Players can join games" ON game_participants;
DROP POLICY IF EXISTS "Users can manage own participation" ON game_participants;

-- Create policy for game participation
CREATE POLICY "Only players can join games"
    ON game_participants FOR INSERT
    TO authenticated
    WITH CHECK (
        -- Check if the user is a player
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'PLAYER'
        )
        AND
        -- Ensure the player is the one joining
        player_id = auth.uid()
        AND
        -- Prevent joining if game is full
        EXISTS (
            SELECT 1 FROM games
            WHERE games.id = game_id
            AND games.current_players < games.max_players
        )
    );

-- Create policy for organizer auto-participation
CREATE POLICY "Organizers auto-join own games"
    ON game_participants FOR INSERT
    TO authenticated
    WITH CHECK (
        -- Allow organizers to be added only to their own games
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'ORGANIZER'
            AND EXISTS (
                SELECT 1 FROM games
                WHERE games.id = game_id
                AND games.organizer_id = auth.uid()
            )
        )
        AND player_id = auth.uid()
    );

-- Create policy for viewing game participants
CREATE POLICY "View game participants"
    ON game_participants FOR SELECT
    TO authenticated
    USING (
        -- Players can view games they've joined
        EXISTS (
            SELECT 1 FROM game_participants gp
            WHERE gp.game_id = game_participants.game_id
            AND gp.player_id = auth.uid()
        )
        OR
        -- Organizers can view their own games
        EXISTS (
            SELECT 1 FROM games
            WHERE games.id = game_participants.game_id
            AND games.organizer_id = auth.uid()
        )
    );

-- Update join_game function to enforce player-only joining
CREATE OR REPLACE FUNCTION join_game(p_game_id UUID, p_player_id UUID)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
    v_current_players INT;
    v_max_players INT;
    v_user_role TEXT;
BEGIN
    -- Check user role
    SELECT role INTO v_user_role
    FROM profiles
    WHERE id = p_player_id;

    -- Only players can join games
    IF v_user_role != 'PLAYER' THEN
        RETURN json_build_object('error', 'Only players can join games');
    END IF;

    -- Check if player has already joined
    IF EXISTS (
        SELECT 1 FROM game_participants 
        WHERE game_id = p_game_id AND player_id = p_player_id
    ) THEN
        RETURN json_build_object('error', 'You have already joined this game');
    END IF;

    -- Get game details with lock
    SELECT current_players, max_players 
    INTO v_current_players, v_max_players
    FROM games 
    WHERE id = p_game_id
    FOR UPDATE;

    -- Check if game is full
    IF v_current_players >= v_max_players THEN
        RETURN json_build_object('error', 'This game is full');
    END IF;

    -- Create participant entry and update count atomically
    BEGIN
        INSERT INTO game_participants (
            game_id,
            player_id,
            status,
            is_ready
        ) VALUES (
            p_game_id,
            p_player_id,
            'PENDING',
            false
        );

        UPDATE games 
        SET current_players = current_players + 1
        WHERE id = p_game_id;

        RETURN json_build_object(
            'success', true,
            'message', 'Successfully joined game'
        );
    EXCEPTION 
        WHEN unique_violation THEN
            RETURN json_build_object('error', 'You have already joined this game');
        WHEN OTHERS THEN
            RAISE;
    END;
END;
$$;

-- Notify PostgREST to reload schema
NOTIFY pgrst, 'reload schema';