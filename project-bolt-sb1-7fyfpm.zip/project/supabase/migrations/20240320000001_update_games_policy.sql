-- Drop existing policy if it exists
DROP POLICY IF EXISTS "Organizers can create games" ON games;

-- Create new policy with stricter organizer status check
CREATE POLICY "Organizers can create games"
    ON games FOR INSERT
    TO authenticated
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND (
                -- Allow if user is an admin
                (profiles.role = 'ADMIN') 
                OR 
                -- Allow if user is an approved organizer
                (
                    profiles.role = 'ORGANIZER' 
                    AND profiles.organizer_status = 'APPROVED'
                )
            )
        )
        AND
        -- Ensure organizer_id matches the authenticated user
        organizer_id = auth.uid()
    );

-- Create a trigger function to double-check organizer status
CREATE OR REPLACE FUNCTION check_organizer_status()
RETURNS TRIGGER AS $$
BEGIN
    -- Verify organizer status before allowing game creation
    IF NOT EXISTS (
        SELECT 1 FROM profiles
        WHERE id = NEW.organizer_id
        AND (
            (role = 'ADMIN') OR
            (role = 'ORGANIZER' AND organizer_status = 'APPROVED')
        )
    ) THEN
        RAISE EXCEPTION 'Only approved organizers can create games';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to enforce organizer status check
DROP TRIGGER IF EXISTS check_organizer_status_trigger ON games;
CREATE TRIGGER check_organizer_status_trigger
    BEFORE INSERT ON games
    FOR EACH ROW
    EXECUTE FUNCTION check_organizer_status();

-- Notify PostgREST to reload schema
NOTIFY pgrst, 'reload schema';