-- Create function to handle game joining in a transaction
CREATE OR REPLACE FUNCTION join_game(p_game_id UUID, p_player_id UUID)
RETURNS json
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_current_players INT;
  v_max_players INT;
BEGIN
  -- Get current game status
  SELECT current_players, max_players 
  INTO v_current_players, v_max_players
  FROM games 
  WHERE id = p_game_id
  FOR UPDATE;

  -- Check if game is full
  IF v_current_players >= v_max_players THEN
    RETURN json_build_object('error', 'Game is full');
  END IF;

  -- Check if player has already joined
  IF EXISTS (
    SELECT 1 FROM game_participants 
    WHERE game_id = p_game_id AND player_id = p_player_id
  ) THEN
    RETURN json_build_object('error', 'Already joined');
  END IF;

  -- Create participant entry
  INSERT INTO game_participants (
    game_id,
    player_id,
    status,
    is_ready
  ) VALUES (
    p_game_id,
    p_player_id,
    'PENDING',
    false
  );

  -- Increment player count
  UPDATE games 
  SET current_players = current_players + 1
  WHERE id = p_game_id;

  RETURN json_build_object(
    'success', true,
    'message', 'Successfully joined game'
  );
END;
$$;

-- Grant execute permission to authenticated users
GRANT EXECUTE ON FUNCTION join_game TO authenticated;