-- Drop existing policies
DROP POLICY IF EXISTS "Organizers can create games" ON games;
DROP POLICY IF EXISTS "Users can manage own participation" ON game_participants;

-- Create policy for game creation
CREATE POLICY "Organizers can create games"
    ON games FOR INSERT
    TO authenticated
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'ORGANIZER'
            AND profiles.organizer_status = 'APPROVED'
        )
        AND
        organizer_id = auth.uid()
    );

-- Create policy to prevent organizers from joining other games
CREATE POLICY "Players can join games"
    ON game_participants FOR INSERT
    TO authenticated
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND (
                -- Allow players to join any game
                (profiles.role = 'PLAYER')
                OR
                -- Allow organizers to be auto-added to their own games only
                (
                    profiles.role = 'ORGANIZER'
                    AND EXISTS (
                        SELECT 1 FROM games
                        WHERE games.id = game_participants.game_id
                        AND games.organizer_id = auth.uid()
                    )
                )
            )
        )
    );

-- Create policy for removing participants
CREATE POLICY "Organizers can remove participants"
    ON game_participants FOR DELETE
    TO authenticated
    USING (
        -- Allow organizers to remove participants from their own games
        EXISTS (
            SELECT 1 FROM games
            WHERE games.id = game_participants.game_id
            AND games.organizer_id = auth.uid()
        )
        AND
        -- Prevent removing the organizer
        NOT EXISTS (
            SELECT 1 FROM games
            WHERE games.id = game_participants.game_id
            AND games.organizer_id = game_participants.player_id
        )
    );

-- Function to handle participant removal
CREATE OR REPLACE FUNCTION handle_participant_removal()
RETURNS TRIGGER AS $$
BEGIN
    -- Decrement current_players count
    UPDATE games
    SET current_players = current_players - 1
    WHERE id = OLD.game_id;

    -- Add removal announcement
    INSERT INTO messages (
        game_id,
        user_id,
        content,
        type
    ) VALUES (
        OLD.game_id,
        auth.uid(),
        'A participant has been removed from the game',
        'ANNOUNCEMENT'
    );

    RETURN OLD;
END;
$$ LANGUAGE plpgsql;

-- Create trigger for participant removal
CREATE TRIGGER on_participant_removed
    AFTER DELETE ON game_participants
    FOR EACH ROW
    EXECUTE FUNCTION handle_participant_removal();

-- Notify PostgREST to reload schema
NOTIFY pgrst, 'reload schema';