-- Drop and recreate venues table with correct schema
DROP TABLE IF EXISTS venues CASCADE;

CREATE TABLE venues (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    sports_supported TEXT[] NOT NULL,
    facilities TEXT[] DEFAULT '{}',
    opening_time TIME NOT NULL,
    closing_time TIME NOT NULL,
    contact_phone TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    CONSTRAINT proper_phone CHECK (contact_phone ~* '^\+?[0-9\s-]+$')
);

-- Create indexes
CREATE INDEX idx_venues_status ON venues(status);
CREATE INDEX idx_venues_sports ON venues USING gin(sports_supported);

-- Enable RLS
ALTER TABLE venues ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Venues are viewable by everyone"
    ON venues FOR SELECT
    USING (true);

CREATE POLICY "Only admins can insert venues"
    ON venues FOR INSERT
    TO authenticated
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'ADMIN'
        )
    );

CREATE POLICY "Only admins can update venues"
    ON venues FOR UPDATE
    TO authenticated
    USING (
        EXISTS (
            SELECT 1 FROM profiles
            WHERE profiles.id = auth.uid()
            AND profiles.role = 'ADMIN'
        )
    );

-- Grant permissions
GRANT ALL ON venues TO service_role;
GRANT SELECT ON venues TO authenticated;
GRANT INSERT, UPDATE ON venues TO authenticated;