-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create ENUM types
DO $$ 
BEGIN
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'user_role') THEN
        CREATE TYPE user_role AS ENUM ('PLAYER', 'ORGANIZER', 'ADMIN');
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'game_status') THEN
        CREATE TYPE game_status AS ENUM ('UPCOMING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED');
    END IF;
    
    IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'participant_status') THEN
        CREATE TYPE participant_status AS ENUM ('CONFIRMED', 'CANCELLED');
    END IF;
END $$;

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
    id UUID PRIMARY KEY REFERENCES auth.users(id),
    email TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    role user_role NOT NULL DEFAULT 'PLAYER',
    phone TEXT NOT NULL,
    profile_picture TEXT,
    organizer_status TEXT NOT NULL DEFAULT 'NOT_APPLIED',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    CONSTRAINT proper_email CHECK (email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'),
    CONSTRAINT proper_phone CHECK (phone ~* '^\+[1-9]\d{1,14}$')
);

-- Create venues table
CREATE TABLE IF NOT EXISTS venues (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT NOT NULL,
    address TEXT NOT NULL,
    sports_supported TEXT[] NOT NULL,
    status TEXT NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Create games table
CREATE TABLE IF NOT EXISTS games (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sport_type TEXT NOT NULL,
    date DATE NOT NULL,
    time TIME NOT NULL,
    venue_id UUID NOT NULL REFERENCES venues(id),
    organizer_id UUID NOT NULL REFERENCES profiles(id),
    max_players INTEGER NOT NULL,
    current_players INTEGER NOT NULL DEFAULT 0,
    price_per_player DECIMAL(10,2) NOT NULL,
    status game_status NOT NULL DEFAULT 'UPCOMING',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    CONSTRAINT valid_players CHECK (current_players <= max_players)
);

-- Create game participants table
CREATE TABLE IF NOT EXISTS game_participants (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    game_id UUID NOT NULL REFERENCES games(id),
    player_id UUID NOT NULL REFERENCES profiles(id),
    status participant_status NOT NULL DEFAULT 'CONFIRMED',
    joined_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    UNIQUE(game_id, player_id)
);

-- Create messages table
CREATE TABLE IF NOT EXISTS messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    game_id UUID NOT NULL REFERENCES games(id),
    user_id UUID NOT NULL REFERENCES profiles(id),
    content TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- Create profile creation trigger function
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER 
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
    default_role user_role;
    profile_exists boolean;
    max_retries constant int := 5;
    current_try int := 0;
    backoff_interval constant float := 0.1;
BEGIN
    WHILE current_try < max_retries LOOP
        BEGIN
            SELECT EXISTS (
                SELECT 1 FROM profiles WHERE id = NEW.id
            ) INTO profile_exists;

            IF profile_exists THEN
                RETURN NEW;
            END IF;

            default_role := CASE 
                WHEN NEW.raw_user_meta_data->>'role' IN ('PLAYER', 'ORGANIZER', 'ADMIN') 
                THEN (NEW.raw_user_meta_data->>'role')::user_role
                ELSE 'PLAYER'::user_role
            END;

            INSERT INTO public.profiles (
                id,
                email,
                name,
                role,
                phone,
                organizer_status,
                created_at,
                updated_at
            )
            VALUES (
                NEW.id,
                NEW.email,
                COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
                default_role,
                COALESCE(NEW.raw_user_meta_data->>'phone', ''),
                CASE 
                    WHEN default_role = 'ORGANIZER' THEN 'PENDING'
                    ELSE 'NOT_APPLIED'
                END,
                NOW(),
                NOW()
            );

            -- Log successful creation
            INSERT INTO auth.audit_log_entries (
                instance_id,
                uuid,
                event_type,
                metadata
            )
            VALUES (
                auth.uid(),
                NEW.id,
                'profile_created',
                jsonb_build_object(
                    'email', NEW.email,
                    'role', default_role,
                    'attempt', current_try + 1
                )
            );

            RETURN NEW;
        EXCEPTION
            WHEN unique_violation THEN
                SELECT EXISTS (
                    SELECT 1 FROM profiles WHERE id = NEW.id
                ) INTO profile_exists;
                
                IF profile_exists THEN
                    RETURN NEW;
                END IF;
            WHEN OTHERS THEN
                INSERT INTO auth.audit_log_entries (
                    instance_id,
                    uuid,
                    event_type,
                    metadata
                )
                VALUES (
                    auth.uid(),
                    NEW.id,
                    'profile_creation_error',
                    jsonb_build_object(
                        'error', SQLERRM,
                        'attempt', current_try + 1
                    )
                );
        END;
        
        current_try := current_try + 1;
        PERFORM pg_sleep(LEAST(backoff_interval * pow(2, current_try), 1.0));
    END LOOP;

    RETURN NEW;
END;
$$;

-- Create trigger
CREATE TRIGGER on_auth_user_created
    AFTER INSERT ON auth.users
    FOR EACH ROW
    EXECUTE FUNCTION public.handle_new_user();

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_profiles_email_lower ON profiles (lower(email));
CREATE INDEX IF NOT EXISTS idx_profiles_role ON profiles(role);
CREATE INDEX IF NOT EXISTS idx_profiles_organizer_status ON profiles(organizer_status);
CREATE INDEX IF NOT EXISTS idx_games_date ON games(date);
CREATE INDEX IF NOT EXISTS idx_games_status ON games(status);
CREATE INDEX IF NOT EXISTS idx_game_participants_game_id ON game_participants(game_id);
CREATE INDEX IF NOT EXISTS idx_game_participants_player_id ON game_participants(player_id);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE venues ENABLE ROW LEVEL SECURITY;
ALTER TABLE games ENABLE ROW LEVEL SECURITY;
ALTER TABLE game_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Service role can manage profiles"
    ON profiles
    TO service_role
    USING (true)
    WITH CHECK (true);

CREATE POLICY "Users can view all profiles"
    ON profiles FOR SELECT
    TO authenticated, anon
    USING (true);

CREATE POLICY "Users can update own profile"
    ON profiles FOR UPDATE
    TO authenticated
    USING (auth.uid() = id)
    WITH CHECK (auth.uid() = id);

-- Grant permissions
GRANT USAGE ON SCHEMA public TO authenticated, anon, service_role;
GRANT ALL ON ALL TABLES IN SCHEMA public TO service_role;
GRANT SELECT, UPDATE ON profiles TO authenticated;
GRANT SELECT ON venues TO authenticated;
GRANT SELECT ON games TO authenticated;
GRANT SELECT, INSERT ON game_participants TO authenticated;
GRANT SELECT, INSERT ON messages TO authenticated;

-- Disable email confirmation requirement
UPDATE auth.config
SET email_confirmation_required = false
WHERE id = 1;