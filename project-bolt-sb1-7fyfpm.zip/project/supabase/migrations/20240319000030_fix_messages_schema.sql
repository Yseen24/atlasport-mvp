-- Drop and recreate messages table with proper schema
DROP TABLE IF EXISTS messages CASCADE;

CREATE TABLE messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    game_id UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES profiles(id),
    content TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'CHAT',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    CONSTRAINT proper_message_type CHECK (type IN ('CHAT', 'ANNOUNCEMENT'))
);

-- Create indexes
CREATE INDEX idx_messages_game_id ON messages(game_id);
CREATE INDEX idx_messages_created_at ON messages(created_at);
CREATE INDEX idx_messages_type ON messages(type);

-- Enable RLS
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Create RLS policies
CREATE POLICY "Users can view messages for their games"
    ON messages FOR SELECT
    USING (
        EXISTS (
            SELECT 1 FROM game_participants
            WHERE game_participants.game_id = messages.game_id
            AND game_participants.player_id = auth.uid()
        ) OR
        EXISTS (
            SELECT 1 FROM games
            WHERE games.id = messages.game_id
            AND games.organizer_id = auth.uid()
        )
    );

CREATE POLICY "Users can send messages to their games"
    ON messages FOR INSERT
    WITH CHECK (
        EXISTS (
            SELECT 1 FROM game_participants
            WHERE game_participants.game_id = messages.game_id
            AND game_participants.player_id = auth.uid()
        ) OR
        EXISTS (
            SELECT 1 FROM games
            WHERE games.id = messages.game_id
            AND games.organizer_id = auth.uid()
        )
    );

-- Grant permissions
GRANT ALL ON messages TO authenticated;

-- Notify PostgREST to reload schema
NOTIFY pgrst, 'reload schema';