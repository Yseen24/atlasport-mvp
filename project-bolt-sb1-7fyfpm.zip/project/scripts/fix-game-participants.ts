import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Missing Supabase environment variables');
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function fixGameParticipants() {
  try {
    // Add is_ready column
    const { error: columnError } = await supabase.rpc('exec', {
      sql: `
        ALTER TABLE game_participants
        ADD COLUMN IF NOT EXISTS is_ready BOOLEAN NOT NULL DEFAULT false;
      `
    });

    if (columnError) throw columnError;

    // Notify PostgREST to reload schema
    const { error: notifyError } = await supabase.rpc('exec', {
      sql: `NOTIFY pgrst, 'reload schema';`
    });

    if (notifyError) throw notifyError;

    console.log('Successfully added is_ready column to game_participants table');
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  }
}

fixGameParticipants();