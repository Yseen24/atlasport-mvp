import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseKey) {
  throw new Error('Missing Supabase environment variables');
}

const supabase = createClient(supabaseUrl, supabaseKey);

async function migrate() {
  try {
    // Create game_participants table
    await supabase.rpc('exec', {
      sql: `
        CREATE TABLE IF NOT EXISTS game_participants (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          game_id UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
          player_id UUID NOT NULL REFERENCES profiles(id),
          status TEXT NOT NULL DEFAULT 'PENDING',
          is_ready BOOLEAN NOT NULL DEFAULT false,
          joined_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
          CONSTRAINT proper_status CHECK (status IN ('PENDING', 'CONFIRMED', 'DECLINED', 'LEFT')),
          UNIQUE(game_id, player_id)
        );
      `
    });

    // Create messages table
    await supabase.rpc('exec', {
      sql: `
        CREATE TABLE IF NOT EXISTS messages (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          game_id UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
          user_id UUID NOT NULL REFERENCES profiles(id),
          content TEXT NOT NULL,
          type TEXT NOT NULL DEFAULT 'CHAT',
          created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
          CONSTRAINT proper_message_type CHECK (type IN ('CHAT', 'ANNOUNCEMENT'))
        );
      `
    });

    // Create event_reminders table
    await supabase.rpc('exec', {
      sql: `
        CREATE TABLE IF NOT EXISTS event_reminders (
          id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          game_id UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
          user_id UUID NOT NULL REFERENCES profiles(id),
          reminder_time TIMESTAMP WITH TIME ZONE NOT NULL,
          is_enabled BOOLEAN NOT NULL DEFAULT true,
          created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
          UNIQUE(game_id, user_id)
        );
      `
    });

    // Create join_game function
    await supabase.rpc('exec', {
      sql: `
        CREATE OR REPLACE FUNCTION join_game(p_game_id UUID, p_player_id UUID)
        RETURNS json
        LANGUAGE plpgsql
        SECURITY DEFINER
        SET search_path = public
        AS $$
        DECLARE
          v_current_players INT;
          v_max_players INT;
        BEGIN
          -- Check if player has already joined
          IF EXISTS (
            SELECT 1 FROM game_participants 
            WHERE game_id = p_game_id AND player_id = p_player_id
          ) THEN
            RETURN json_build_object('error', 'You have already joined this game');
          END IF;

          -- Get game details with lock
          SELECT current_players, max_players 
          INTO v_current_players, v_max_players
          FROM games 
          WHERE id = p_game_id
          FOR UPDATE;

          -- Check if game is full
          IF v_current_players >= v_max_players THEN
            RETURN json_build_object('error', 'This game is full');
          END IF;

          -- Create participant entry and update count atomically
          BEGIN
            INSERT INTO game_participants (
              game_id,
              player_id,
              status,
              is_ready
            ) VALUES (
              p_game_id,
              p_player_id,
              'PENDING',
              false
            );

            UPDATE games 
            SET current_players = current_players + 1
            WHERE id = p_game_id;

            RETURN json_build_object(
              'success', true,
              'message', 'Successfully joined game'
            );
          EXCEPTION 
            WHEN unique_violation THEN
              RETURN json_build_object('error', 'You have already joined this game');
            WHEN OTHERS THEN
              RAISE;
          END;
        END;
        $$;

        -- Grant execute permission
        GRANT EXECUTE ON FUNCTION join_game TO authenticated;
      `
    });

    // Create indexes
    await supabase.rpc('exec', {
      sql: `
        CREATE INDEX IF NOT EXISTS idx_game_participants_game_id ON game_participants(game_id);
        CREATE INDEX IF NOT EXISTS idx_game_participants_player_id ON game_participants(player_id);
        CREATE INDEX IF NOT EXISTS idx_messages_game_id ON messages(game_id);
        CREATE INDEX IF NOT EXISTS idx_messages_created_at ON messages(created_at);
        CREATE INDEX IF NOT EXISTS idx_event_reminders_game_user ON event_reminders(game_id, user_id);
      `
    });

    // Enable RLS and create policies
    await supabase.rpc('exec', {
      sql: `
        ALTER TABLE game_participants ENABLE ROW LEVEL SECURITY;
        ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
        ALTER TABLE event_reminders ENABLE ROW LEVEL SECURITY;

        -- RLS policies for game_participants
        DROP POLICY IF EXISTS "Users can view all game participants" ON game_participants;
        CREATE POLICY "Users can view all game participants"
          ON game_participants FOR SELECT
          USING (true);

        DROP POLICY IF EXISTS "Users can manage their own participation" ON game_participants;
        CREATE POLICY "Users can manage their own participation"
          ON game_participants
          USING (player_id = auth.uid())
          WITH CHECK (player_id = auth.uid());

        -- RLS policies for messages
        DROP POLICY IF EXISTS "Users can view messages for their games" ON messages;
        CREATE POLICY "Users can view messages for their games"
          ON messages FOR SELECT
          USING (EXISTS (
            SELECT 1 FROM game_participants
            WHERE game_participants.game_id = messages.game_id
            AND game_participants.player_id = auth.uid()
          ));

        DROP POLICY IF EXISTS "Users can send messages to their games" ON messages;
        CREATE POLICY "Users can send messages to their games"
          ON messages FOR INSERT
          WITH CHECK (EXISTS (
            SELECT 1 FROM game_participants
            WHERE game_participants.game_id = messages.game_id
            AND game_participants.player_id = auth.uid()
          ));

        -- RLS policies for event_reminders
        DROP POLICY IF EXISTS "Users can manage their own reminders" ON event_reminders;
        CREATE POLICY "Users can manage their own reminders"
          ON event_reminders
          USING (user_id = auth.uid())
          WITH CHECK (user_id = auth.uid());

        -- Grant permissions
        GRANT ALL ON game_participants TO authenticated;
        GRANT ALL ON messages TO authenticated;
        GRANT ALL ON event_reminders TO authenticated;
      `
    });

    console.log('Migrations completed successfully');
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  }
}

migrate();