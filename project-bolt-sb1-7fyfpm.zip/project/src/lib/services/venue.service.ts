import { supabase } from '../supabase';
import type { VenueFormData, Venue } from '../../types';

export class VenueService {
 static async createVenue(formData: VenueFormData) {
   try {
     const venueData = {
       name: formData.name.trim(),
       address: formData.address.trim(),
       sports_supported: formData.sports_supported,
       facilities: formData.facilities || [],
       openingTime: formData.openingTime,
       closingTime: formData.closingTime,
       contactPhone: formData.contactPhone.trim(),
       status: 'ACTIVE',
       updated_at: '',
     } satisfies Omit<Venue, 'id' | 'created_at'>;

     const { data, error } = await supabase
       .from('venues')
       .insert([venueData])
       .select('*, sports_supported')
       .single();

     if (error) {
       console.error('Venue creation error:', error);
       throw new Error(error.message);
     }

     return { data, error: null };
   } catch (error) {
     console.error('Error creating venue:', error);
     return { 
       data: null, 
       error: error instanceof Error ? error : new Error('Failed to create venue')
     };
   }
 }

 static async getVenues() {
  try {
    const { data, error } = await supabase
      .from('venues')
      .select(`
        id,
        name,
        address,
        sports_supported,
        status,
        created_at,
        facilities,
        opening_time,
        closing_time,
        contact_phone,
      `)
      .eq('status', 'ACTIVE')
      .order('created_at', { ascending: false });

    if (error) throw error;
    
    // Add type assertion to match your Venue interface
    return { 
      data: data ? data as unknown as Venue[] : null, 
      error: null 
    };
  } catch (error) {
    console.error('Error fetching venues:', error);
    return { 
      data: null, 
      error: error instanceof Error ? error : new Error('Failed to fetch venues')
    };
  }
}

 static async getVenueById(venueId: string) {
   try {
     const { data, error } = await supabase
       .from('venues')
       .select(`
         id,
         name,
         address,
         sports_supported,
         facilities,
         opening_time,
         closing_time,
         contact_phone,
         status,
         created_at
       `)
       .eq('id', venueId)
       .single();

     if (error) throw error;
     return { data: data as unknown as Venue, error: null };
   } catch (error) {
     console.error('Error fetching venue:', error);
     return {
       data: null,
       error: error instanceof Error ? error : new Error('Failed to fetch venue')
     };
   }
 }

 static async updateVenue(venueId: string, formData: Partial<VenueFormData>) {
   try {
     const venueData = {
       ...(formData.name && { name: formData.name.trim() }),
       ...(formData.address && { address: formData.address.trim() }),
       ...(formData.sports_supported && { sports_supported: formData.sports_supported }),
       ...(formData.facilities && { facilities: formData.facilities }),
       ...(formData.openingTime && { opening_time: formData.openingTime }),
       ...(formData.closingTime && { closing_time: formData.closingTime }),
       ...(formData.contactPhone && { contact_phone: formData.contactPhone.trim() })
     };

     const { data, error } = await supabase
       .from('venues')
       .update(venueData)
       .eq('id', venueId)
       .select()
       .single();

     if (error) throw error;
     return { data: data as Venue, error: null };
   } catch (error) {
     console.error('Error updating venue:', error);
     return {
       data: null,
       error: error instanceof Error ? error : new Error('Failed to update venue')
     };
   }
 }

 static async deleteVenue(venueId: string) {
   try {
     const { error } = await supabase
       .from('venues')
       .update({ status: 'INACTIVE' })
       .eq('id', venueId);

     if (error) throw error;
     return { error: null };
   } catch (error) {
     console.error('Error deleting venue:', error);
     return {
       error: error instanceof Error ? error : new Error('Failed to delete venue')
     };
   }
 }
}