import { supabase } from '../supabase';

export class GameService {
  static async getVenues() {
    try {
      const { data, error } = await supabase
        .from('venues')
        .select('*')
        .eq('status', 'ACTIVE')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      console.error('Error fetching venues:', error);
      return { 
        data: null, 
        error: error instanceof Error ? error : new Error('Failed to fetch venues')
      };
    }
  }

  static async createGame(gameData: any) {
    try {
      const { data, error } = await supabase
        .from('games')
        .insert([gameData])
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      console.error('Error creating game:', error);
      return { 
        data: null, 
        error: error instanceof Error ? error : new Error('Failed to create game')
      };
    }
  }
}