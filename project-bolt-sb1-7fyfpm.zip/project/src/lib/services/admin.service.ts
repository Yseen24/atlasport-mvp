import { supabase } from '../supabase';

export class AdminService {
  static async createDefaultAdmin() {
    const email = 'admin@atlasport.com';
    const password = 'Admin123!';
    const name = 'Admin User';

    try {
      // Check if admin already exists
      const { data: existingUser } = await supabase
        .from('profiles')
        .select('*')
        .eq('email', email)
        .eq('role', 'ADMIN')
        .single();

      if (existingUser) {
        return {
          email,
          password,
          message: 'Admin account already exists'
        };
      }

      // Create admin user
      const { data: { user }, error: signUpError } = await supabase.auth.signUp({
        email,
        password,
        options: {
          data: {
            name,
            role: 'ADMIN',
            phone: '+1234567890'
          }
        }
      });

      if (signUpError || !user) {
        throw new Error('Failed to create admin account');
      }

      // Wait for profile trigger
      await new Promise(resolve => setTimeout(resolve, 1000));

      return {
        email,
        password,
        message: 'Admin account created successfully'
      };
    } catch (error) {
      console.error('Error creating admin:', error);
      throw error;
    }
  }
}