import { supabase } from '../supabase';
import type { RegisterFormData, User } from '../../types';
import { getAuthErrorMessage } from '../utils/auth-errors';

class AuthService {
  async checkEmailExists(email: string): Promise<boolean> {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('id')
        .eq('email', email)
        .maybeSingle();

      if (error) throw error;
      return !!data;
    } catch (error) {
      console.error('Error checking email:', error);
      return false;
    }
  }

  async signUp(formData: RegisterFormData) {
    try {
      // Check if email exists first
      const emailExists = await this.checkEmailExists(formData.email);
      if (emailExists) {
        throw new Error('An account with this email already exists');
      }

      // Create auth user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: formData.email,
        password: formData.password,
        options: {
          data: {
            name: formData.name,
            role: formData.role.toUpperCase(),
            phone: formData.phone
          }
        }
      });

      if (authError) throw authError;
      if (!authData.user) throw new Error('Failed to create user account');

      // Wait for profile trigger to complete
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Fetch the created profile
      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', authData.user.id)
        .single();

      if (profileError || !profile) {
        // If profile doesn't exist, create it manually
        const { data: newProfile, error: insertError } = await supabase
          .from('profiles')
          .insert({
            id: authData.user.id,
            email: formData.email,
            name: formData.name,
            role: formData.role.toUpperCase(),
            phone: formData.phone,
            organizer_status: formData.role.toUpperCase() === 'ORGANIZER' ? 'PENDING' : 'NOT_APPLIED'
          })
          .select()
          .single();

        if (insertError) throw new Error('Failed to create profile');
        return { user: authData.user, profile: newProfile };
      }

      return { user: authData.user, profile };
    } catch (error) {
      console.error('SignUp error:', error);
      throw new Error(getAuthErrorMessage(error));
    }
  }

  async signIn(email: string, password: string) {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) throw error;
      if (!data.user) throw new Error('Failed to sign in');

      const { data: profile, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', data.user.id)
        .single();

      if (profileError || !profile) throw new Error('User profile not found');

      return { user: data.user, profile };
    } catch (error) {
      console.error('SignIn error:', error);
      throw new Error(getAuthErrorMessage(error));
    }
  }

  async signOut() {
    const { error } = await supabase.auth.signOut();
    if (error) throw error;
  }

  async getProfile(userId: string): Promise<User | null> {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) throw error;
      return data;
    } catch (error) {
      console.error('Error fetching profile:', error);
      return null;
    }
  }
}

export const authService = new AuthService();