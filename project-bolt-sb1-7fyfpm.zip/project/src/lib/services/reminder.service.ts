import { supabase } from '../supabase';
import type { EventReminder } from '../../types/event';

export class ReminderService {
  static async getReminders(gameId: string, userId: string) {
    try {
      const { data, error } = await supabase
        .from('event_reminders')
        .select('*')
        .eq('game_id', gameId)
        .eq('user_id', userId);

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error fetching reminders:', err);
      return { 
        data: null, 
        error: err instanceof Error ? err.message : 'Failed to fetch reminders'
      };
    }
  }

  static async setReminder(reminder: Omit<EventReminder, 'id' | 'createdAt'>) {
    try {
      const { data, error } = await supabase
        .from('event_reminders')
        .upsert({
          game_id: reminder.gameId,
          user_id: reminder.userId,
          reminder_time: reminder.reminderTime,
          is_enabled: reminder.isEnabled
        })
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (err) {
      console.error('Error setting reminder:', err);
      return { 
        data: null, 
        error: err instanceof Error ? err.message : 'Failed to set reminder'
      };
    }
  }

  static async removeReminder(reminderId: string, userId: string) {
    try {
      const { error } = await supabase
        .from('event_reminders')
        .delete()
        .eq('id', reminderId)
        .eq('user_id', userId);

      if (error) throw error;
      return { error: null };
    } catch (err) {
      console.error('Error removing reminder:', err);
      return { 
        error: err instanceof Error ? err.message : 'Failed to remove reminder'
      };
    }
  }
}