import { supabase } from './supabase';

export async function createDefaultAdmin() {
  const email = 'admin@atlasport.com';
  const password = 'Admin123!';

  // Check if admin already exists
  const { data: existingUser } = await supabase
    .from('profiles')
    .select('*')
    .eq('email', email)
    .single();

  if (existingUser) {
    return {
      email,
      password,
      message: 'Admin account already exists'
    };
  }

  // Create admin user
  const { data: { user }, error: signUpError } = await supabase.auth.signUp({
    email,
    password,
  });

  if (signUpError || !user) {
    throw new Error('Failed to create admin account');
  }

  // Create admin profile
  const { error: profileError } = await supabase
    .from('profiles')
    .insert({
      id: user.id,
      email,
      name: 'Admin User',
      role: 'ADMIN',
      phone: '0000000000',
      organizer_status: 'NOT_APPLIED'
    });

  if (profileError) {
    throw new Error('Failed to create admin profile');
  }

  return {
    email,
    password,
    message: 'Admin account created successfully'
  };
}