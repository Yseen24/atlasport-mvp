import { runMigration } from '../utils/db';

const migrations = [
  // Event reminders table
  `
  CREATE TABLE IF NOT EXISTS event_reminders (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    game_id UUID NOT NULL REFERENCES games(id) ON DELETE CASCADE,
    user_id UUID NOT NULL REFERENCES profiles(id),
    reminder_time TIMESTAMP WITH TIME ZONE NOT NULL,
    is_enabled BOOLEAN NOT NULL DEFAULT true,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
    UNIQUE(game_id, user_id)
  );

  -- Create index for better query performance
  CREATE INDEX IF NOT EXISTS idx_event_reminders_game_user ON event_reminders(game_id, user_id);

  -- Enable RLS
  ALTER TABLE event_reminders ENABLE ROW LEVEL SECURITY;

  -- Create RLS policies
  CREATE POLICY IF NOT EXISTS "Users can manage their own reminders"
    ON event_reminders
    USING (user_id = auth.uid())
    WITH CHECK (user_id = auth.uid());

  -- Grant permissions
  GRANT ALL ON event_reminders TO service_role;
  GRANT SELECT, INSERT, UPDATE, DELETE ON event_reminders TO authenticated;
  `
];

export async function runMigrations() {
  for (const sql of migrations) {
    const { error } = await runMigration(sql);
    if (error) {
      console.error('Migration failed:', error);
      return { error };
    }
  }
  return { error: null };
}