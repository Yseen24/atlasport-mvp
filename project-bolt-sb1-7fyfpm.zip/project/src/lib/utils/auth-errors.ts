// src/lib/utils/auth-errors.ts

export const AUTH_ERROR_MESSAGES = {
  // Authentication errors
  invalid_credentials: 'The email or password you entered is incorrect',
  user_already_exists: 'An account with this email already exists',
  weak_password: 'Password must be at least 6 characters',
  invalid_email: 'Please enter a valid email address',
  email_taken: 'This email is already registered',
  
  // Network/server errors
  timeout: 'Connection timed out. Please check your internet and try again',
  server_error: 'Our servers are having issues. Please try again in a few minutes',
  
  // Generic error
  default: 'Something went wrong. Please try again'
} as const;

export type AuthErrorCode = keyof typeof AUTH_ERROR_MESSAGES;

export function getAuthErrorMessage(error: unknown): string {
  if (error instanceof AuthError) {
    // Handle Supabase auth errors
    if (error.status === 400) {
      if (error.message.includes('credentials')) {
        return AUTH_ERROR_MESSAGES.invalid_credentials;
      }
    }
    
    if (error.status === 422) {
      if (error.message.includes('already registered')) {
        return AUTH_ERROR_MESSAGES.email_taken;
      }
      return AUTH_ERROR_MESSAGES.user_already_exists;
    }
    
    const message = AUTH_ERROR_MESSAGES[error.message as AuthErrorCode];
    return message || error.message;
  }
  
  if (error instanceof Error) {
    // Check for known error messages
    if (error.message.toLowerCase().includes('network')) {
      return 'Please check your internet connection and try again';
    }
    if (error.message.toLowerCase().includes('timeout')) {
      return AUTH_ERROR_MESSAGES.timeout;
    }
    if (error.message.toLowerCase().includes('email exists')) {
      return AUTH_ERROR_MESSAGES.email_taken;
    }
    return error.message;
  }
  
  return AUTH_ERROR_MESSAGES.default;
}

export function isAuthError(error: unknown): error is AuthError {
  return error instanceof AuthError;
}
