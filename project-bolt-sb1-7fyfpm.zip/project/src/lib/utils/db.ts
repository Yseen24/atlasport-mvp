import { supabase } from '../supabase';

export async function runMigration(sql: string) {
  try {
    const { error } = await supabase.rpc('run_migration', { sql });
    if (error) throw error;
    return { error: null };
  } catch (err) {
    console.error('Migration error:', err);
    return { error: err instanceof Error ? err.message : 'Migration failed' };
  }
}