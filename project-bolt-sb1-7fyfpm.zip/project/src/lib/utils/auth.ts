import { AuthError } from '@supabase/supabase-js';

export function getAuthErrorMessage(error: AuthError | Error | unknown): string {
  if (error instanceof AuthError) {
    switch (error.message) {
      case 'Invalid login credentials':
        return 'Invalid email or password';
      case 'User already registered':
        return 'An account with this email already exists';
      default:
        return error.message;
    }
  }
  
  if (error instanceof Error) {
    switch (error.message) {
      case 'Failed to create user account':
        return 'Unable to create account. Please try again.';
      case 'Failed to create user profile':
        return 'Account created but profile setup failed. Please try again.';
      case 'User profile not found':
        return 'User profile not found. Please try again.';
      default:
        return error.message;
    }
  }
  
  return 'An unexpected error occurred. Please try again.';
}

export function validatePassword(password: string): boolean {
  return password.length >= 6;
}

export async function validateRegistration(formData: {
  email: string;
  password: string;
  name: string;
  phone: string;
}): Promise<string | null> {
  if (!formData.email || !formData.password || !formData.name || !formData.phone) {
    return 'All fields are required';
  }
  
  if (!validatePassword(formData.password)) {
    return 'Password must be at least 6 characters';
  }

  if (!formData.email.match(/^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/)) {
    return 'Please enter a valid email address';
  }

  if (!formData.phone.match(/^\+?[0-9]{6,15}$/)) {
    return 'Please enter a valid phone number';
  }
  
  return null;
}