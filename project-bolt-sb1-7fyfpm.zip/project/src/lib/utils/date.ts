import { format, isValid, parse } from 'date-fns';

export function formatDate(date: Date | string): string {
  const parsedDate = typeof date === 'string' ? new Date(date) : date;
  return isValid(parsedDate) ? format(parsedDate, 'MMM dd, yyyy') : 'Invalid date';
}

export function formatTime(time: string): string {
  const parsedTime = parse(time, 'HH:mm', new Date());
  return isValid(parsedTime) ? format(parsedTime, 'h:mm a') : time;
}

export function isDateInFuture(date: Date | string): boolean {
  const parsedDate = typeof date === 'string' ? new Date(date) : date;
  return isValid(parsedDate) && parsedDate > new Date();
}