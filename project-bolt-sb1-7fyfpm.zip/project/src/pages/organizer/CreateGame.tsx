import { GameForm } from '../../components/organizer/GameForm';

export function CreateGame() {
  return (
    <div className="max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Create New Game</h1>
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <GameForm />
      </div>
    </div>
  );
}