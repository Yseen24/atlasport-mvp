import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { useOrganizerGames } from '../../hooks/useOrganizerGames';
import { Button } from '../../components/ui/Button';
import { Alert } from '../../components/ui/Alert';
import { Plus, Calendar, Users, MapPin, Clock } from 'lucide-react';
import { format } from 'date-fns';

export function OrganizerDashboard() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { games, isLoading, error } = useOrganizerGames(user?.id || '');

  if (!user || user.role !== 'ORGANIZER') {
    navigate('/unauthorized');
    return null;
  }

  const upcomingGames = games.filter(game => game.status === 'UPCOMING');
  const pastGames = games.filter(game => ['COMPLETED', 'CANCELLED'].includes(game.status));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Organizer Dashboard</h1>
          <p className="mt-2 text-gray-600">
            Manage your games and monitor participant activity
          </p>
        </div>
        <Link
          to="/organizer/games/create"
          className="inline-flex items-center px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition-colors"
        >
          <Plus className="w-5 h-5 mr-2" />
          Create Game
        </Link>
      </div>

      {error && (
        <Alert
          type="error"
          message={error}
        />
      )}

      {isLoading ? (
        <div className="text-center py-12">
          <div className="text-gray-600">Loading your games...</div>
        </div>
      ) : (
        <div className="grid gap-6">
          {/* Upcoming Games */}
          <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-xl font-semibold text-gray-900">Upcoming Games</h2>
            </div>
            {upcomingGames.length === 0 ? (
              <div className="p-6 text-center text-gray-600">
                <p>You haven't created any upcoming games yet.</p>
                <Button
                  onClick={() => navigate('/organizer/games/create')}
                  className="mt-4"
                >
                  Create Your First Game
                </Button>
              </div>
            ) : (
              <div className="divide-y divide-gray-200">
                {upcomingGames.map(game => (
                  <div key={game.id} className="p-6 hover:bg-gray-50 transition-colors">
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <h3 className="text-lg font-medium text-gray-900">
                          {game.sport_type}
                        </h3>
                        <div className="flex items-center text-sm text-gray-500 space-x-4">
                          <span className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            {format(new Date(game.date), 'MMM d, yyyy')}
                          </span>
                          <span className="flex items-center">
                            <Clock className="w-4 h-4 mr-1" />
                            {game.time}
                          </span>
                          <span className="flex items-center">
                            <MapPin className="w-4 h-4 mr-1" />
                            {game.venue?.name}
                          </span>
                          <span className="flex items-center">
                            <Users className="w-4 h-4 mr-1" />
                            {game.current_players}/{game.max_players} players
                          </span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          onClick={() => navigate(`/games/${game.id}`)}
                        >
                          View Details
                        </Button>
                        <Button
                          onClick={() => navigate(`/games/${game.id}/manage`)}
                        >
                          Manage Game
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Past Games */}
          {pastGames.length > 0 && (
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
              <div className="p-6 border-b border-gray-200">
                <h2 className="text-xl font-semibold text-gray-900">Past Games</h2>
              </div>
              <div className="divide-y divide-gray-200">
                {pastGames.map(game => (
                  <div key={game.id} className="p-6">
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <h3 className="text-lg font-medium text-gray-900">
                          {game.sport_type}
                        </h3>
                        <div className="flex items-center text-sm text-gray-500 space-x-4">
                          <span className="flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            {format(new Date(game.date), 'MMM d, yyyy')}
                          </span>
                          <span className="flex items-center">
                            <Users className="w-4 h-4 mr-1" />
                            {game.current_players} participants
                          </span>
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800">
                            {game.status}
                          </span>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        onClick={() => navigate(`/games/${game.id}`)}
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}