import React from 'react';
import { useAuthStore } from '../../store/authStore';

export function PlayerDashboard() {
  const { user } = useAuthStore();

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-900">Player Dashboard</h1>
      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <h2 className="text-xl font-semibold mb-4">Welcome back, {user?.name}</h2>
        <div className="grid gap-6 md:grid-cols-2">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-medium mb-2">Upcoming Games</h3>
            <p className="text-gray-600">You have no upcoming games</p>
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="font-medium mb-2">Game History</h3>
            <p className="text-gray-600">No past games found</p>
          </div>
        </div>
      </div>
    </div>
  );
}