import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';
import { RegistrationForm } from '../../components/auth/RegistrationForm';
import { Alert } from '../../components/ui/Alert';
import type { RegisterFormData } from '../../types';

export function RegisterPage() {
  const navigate = useNavigate();
  const { signUp, isLoading, error } = useAuth();
  const [showSuccess, setShowSuccess] = React.useState(false);

  const handleSubmit = async (data: RegisterFormData) => {
    const { success } = await signUp(data);
    
    if (success) {
      setShowSuccess(true);
      // Show success message for 3 seconds before redirecting
      setTimeout(() => {
        navigate('/profile', { 
          replace: true,
          state: { 
            welcome: true,
            message: `Welcome to Atlasport, ${data.name}! Please take a moment to review your profile information.`
          }
        });
      }, 3000);
    }
  };

  return (
    <div className="max-w-md mx-auto">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Create an account</h1>
        <p className="mt-2 text-gray-600">Join the Atlasport community</p>
      </div>

      <div className="bg-white rounded-lg border border-gray-200 p-6 shadow-sm">
        {showSuccess ? (
          <div className="text-center py-8">
            <Alert
              type="success"
              message="Account created successfully! Redirecting to your profile..."
              className="mb-4"
            />
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
          </div>
        ) : (
          <RegistrationForm 
            onSubmit={handleSubmit} 
            error={error} 
            isSubmitting={isLoading}
          />
        )}
      </div>
    </div>
  );
}