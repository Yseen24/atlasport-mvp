import React from 'react';
import { useNavigate } from 'react-router-dom';
import { VenueForm } from '../../../components/venues/VenueForm';
import { Alert } from '../../../components/ui/Alert';
import { useVenues } from '../../../hooks/useVenues';
import { useAuthStore } from '../../../store/authStore';
import type { VenueFormData } from '../../../types';

export function CreateVenue() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { createVenue, isLoading, error } = useVenues();
  const [status, setStatus] = React.useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  React.useEffect(() => {
    if (!user || user.role !== 'ADMIN') {
      navigate('/unauthorized');
    }
  }, [user, navigate]);

  const handleSubmit = async (data: VenueFormData) => {
    try {
      const { error: venueError } = await createVenue(data);

      if (venueError) {
        setStatus({
          type: 'error',
          message: venueError
        });
        return;
      }

      setStatus({
        type: 'success',
        message: 'Venue created successfully!'
      });

      // Redirect after success message
      setTimeout(() => {
        navigate('/admin/dashboard');
      }, 2000);
    } catch (err) {
      setStatus({
        type: 'error',
        message: 'Failed to create venue. Please try again.'
      });
    }
  };

  if (!user || user.role !== 'ADMIN') {
    return null;
  }

  return (
    <div className="max-w-4xl mx-auto">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Add New Venue</h1>
      
      {(status || error) && (
        <Alert
          type={status?.type || 'error'}
          message={status?.message || error}
          className="mb-6"
        />
      )}

      <div className="bg-white rounded-lg border border-gray-200 p-6">
        <VenueForm 
          onSubmit={handleSubmit}
          isSubmitting={isLoading}
        />
      </div>
    </div>
  );
}