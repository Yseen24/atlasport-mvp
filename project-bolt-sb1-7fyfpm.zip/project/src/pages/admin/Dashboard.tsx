import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { useOrganizerApplications } from '../../hooks/useOrganizerApplications';
import { VenueService } from '../../lib/services/venue.service';
import { Button } from '../../components/ui/Button';
import { Alert } from '../../components/ui/Alert';
import { Plus, Users, MapPin } from 'lucide-react';

export function AdminDashboard() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { 
    applications = [], 
    isLoading: isLoadingApplications, 
    approveOrganizer, 
    rejectOrganizer 
  } = useOrganizerApplications();
  const [venues, setVenues] = React.useState([]);
  const [isLoadingVenues, setIsLoadingVenues] = React.useState(true);
  const [alert, setAlert] = React.useState<{ type: 'success' | 'error'; message: string } | null>(null);

  React.useEffect(() => {
    if (!user || user.role !== 'ADMIN') {
      navigate('/unauthorized');
      return;
    }

    const fetchVenues = async () => {
      try {
        const { data, error: venueError } = await VenueService.getVenues();
        if (venueError) throw venueError;
        setVenues(data || []);
      } catch (err) {
        setAlert({
          type: 'error',
          message: err instanceof Error ? err.message : 'Failed to load venues'
        });
      } finally {
        setIsLoadingVenues(false);
      }
    };

    fetchVenues();
  }, [user, navigate]);

  const handleApprove = async (userId: string) => {
    try {
      const { error } = await approveOrganizer(userId);
      
      if (error) {
        setAlert({ type: 'error', message: error });
        return;
      }

      setAlert({ 
        type: 'success', 
        message: 'Organizer approved successfully' 
      });
    } catch (err) {
      setAlert({ 
        type: 'error', 
        message: 'Failed to approve organizer' 
      });
    }
  };

  const handleReject = async (userId: string) => {
    try {
      const { error } = await rejectOrganizer(userId);
      
      if (error) {
        setAlert({ type: 'error', message: error });
        return;
      }

      setAlert({ 
        type: 'success', 
        message: 'Organizer application rejected' 
      });
    } catch (err) {
      setAlert({ 
        type: 'error', 
        message: 'Failed to reject organizer' 
      });
    }
  };

  if (!user || user.role !== 'ADMIN') {
    return null;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
        <Button
          onClick={() => navigate('/admin/venues/create')}
          className="inline-flex items-center"
        >
          <Plus className="w-5 h-5 mr-2" />
          Add New Venue
        </Button>
      </div>

      {alert && (
        <Alert
          type={alert.type}
          message={alert.message}
          className="mb-6"
        />
      )}

      <div className="grid gap-6 md:grid-cols-2">
        {/* Pending Organizers */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900 flex items-center">
              <Users className="w-5 h-5 mr-2 text-gray-500" />
              Pending Organizers
            </h2>
          </div>

          {isLoadingApplications ? (
            <div className="text-gray-600">Loading applications...</div>
          ) : applications.length === 0 ? (
            <div className="text-gray-600">No pending applications</div>
          ) : (
            <div className="space-y-4">
              {applications.map((application) => (
                <div
                  key={application.id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                >
                  <div>
                    <p className="font-medium text-gray-900">{application.name}</p>
                    <p className="text-sm text-gray-600">{application.email}</p>
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleReject(application.id)}
                    >
                      Reject
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleApprove(application.id)}
                    >
                      Approve
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Active Venues */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-gray-900 flex items-center">
              <MapPin className="w-5 h-5 mr-2 text-gray-500" />
              Active Venues
            </h2>
          </div>

          {isLoadingVenues ? (
            <div className="text-gray-600">Loading venues...</div>
          ) : venues.length === 0 ? (
            <div className="text-gray-600">No venues added yet</div>
          ) : (
            <div className="space-y-4">
              {venues.map((venue: any) => (
                <div
                  key={venue.id}
                  className="p-4 bg-gray-50 rounded-lg"
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-medium text-gray-900">{venue.name}</p>
                      <p className="text-sm text-gray-600">{venue.address}</p>
                    </div>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => navigate(`/admin/venues/${venue.id}`)}
                    >
                      Edit
                    </Button>
                  </div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {venue.sports_supported?.map((sport: string) => (
                      <span
                        key={sport}
                        className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                      >
                        {sport}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}