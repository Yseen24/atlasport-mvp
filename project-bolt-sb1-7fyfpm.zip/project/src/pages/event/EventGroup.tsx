import React from 'react';
import { useParams, Navigate, useLocation } from 'react-router-dom';
import { useEventGroup } from '../../hooks/useEventGroup';
import { useAuthStore } from '../../store/authStore';
import { EventGroupChat } from '../../components/event/EventGroupChat';
import { ParticipantsList } from '../../components/event/ParticipantsList';
import { EventActions } from '../../components/event/EventActions';
import { EventAccessGate } from '../../components/event/EventAccessGate';
import { Alert } from '../../components/ui/Alert';

export function EventGroup() {
  const { gameId } = useParams<{ gameId: string }>();
  const location = useLocation();
  const { user } = useAuthStore();
  
  if (!gameId) {
    return <Navigate to="/games" replace />;
  }

  return (
    <EventAccessGate gameId={gameId}>
      <EventGroupContent gameId={gameId} />
    </EventAccessGate>
  );
}

function EventGroupContent({ gameId }: { gameId: string }) {
  const { user } = useAuthStore();
  const {
    participants,
    messages,
    isLoading,
    error,
    sendMessage,
    updateParticipantStatus,
    toggleReadyStatus
  } = useEventGroup(gameId);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-gray-600">Loading event group...</div>
      </div>
    );
  }

  if (error) {
    return (
      <Alert
        type="error"
        message={error}
      />
    );
  }

  const currentParticipant = participants.find(p => p.userId === user?.id);
  const organizer = participants.find(p => p.userId === gameId);
  const isOrganizer = user?.id === organizer?.userId;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <EventGroupChat
            messages={messages}
            onSendMessage={sendMessage}
            isOrganizer={isOrganizer}
          />
        </div>

        <div className="space-y-6">
          <ParticipantsList
            participants={participants}
            maxPlayers={30}
            organizerId={organizer?.userId || ''}
          />

          {currentParticipant && (
            <EventActions
              gameId={gameId}
              participant={currentParticipant}
              onUpdateStatus={updateParticipantStatus}
              onToggleReady={toggleReadyStatus}
            />
          )}
        </div>
      </div>
    </div>
  );
}