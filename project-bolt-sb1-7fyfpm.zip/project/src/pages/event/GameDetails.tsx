import { useParams, useNavigate, useLocation } from 'react-router-dom';
import { useGameDetails } from '../../hooks/useGameDetails';
import { useGameParticipation } from '../../hooks/useGameParticipation';
import { useAuthStore } from '../../store/authStore';
import { Alert } from '../../components/ui/Alert';
import { Button } from '../../components/ui/Button';
import { JoinGameButton } from '../../components/games/JoinGameButton';
import { MapPin, Users, Clock, Calendar, Trophy, CheckCircle, TimerIcon, Award } from 'lucide-react';
import { format } from 'date-fns';
import React from 'react';

export function GameDetails() {
  const { gameId } = useParams<{ gameId: string }>();
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuthStore();
  const { game, isLoading, error } = useGameDetails(gameId!);
  const { isParticipating } = useGameParticipation(gameId!, user?.id);

  const isOrganizer = user?.role === 'ORGANIZER';
  const isGameOrganizer = user?.id === game?.organizer_id;

  React.useEffect(() => {
    if (!user) {
      navigate('/login', { state: { from: location } });
    }
  }, [user, navigate, location]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-gray-600">Loading game details...</div>
      </div>
    );
  }

  if (error || !game) {
    return (
      <div className="max-w-2xl mx-auto">
        <Alert type="error" message={error || 'Game not found'} />
        <Button onClick={() => navigate('/games')} className="mt-4">
          Back to Games
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto bg-white rounded-lg shadow-sm">
      {/* Header Section */}
      <div className="p-6 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div className="flex items-start gap-4">
            <Trophy className="w-8 h-8 text-emerald-500" />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">{game.title || game.sport_type}</h1>
              <p className="text-gray-600">
                Organized by {game.organizer?.name || 'Organizer'}
              </p>
            </div>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold">
              ${game.price_per_player}
              <span className="text-sm text-gray-500 font-normal">/player</span>
            </div>
            {isParticipating && (
              <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-emerald-100 text-emerald-800">
                <CheckCircle className="w-4 h-4 mr-1" />
                Participating
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Game Details Section */}
      <div className="p-6">
        <div className="grid gap-8 md:grid-cols-2">
          <div className="space-y-6">
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-500">Date</p>
                  <p className="text-gray-900">{format(new Date(game.date), 'MMMM d, yyyy')}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Clock className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-500">Time</p>
                  <p className="text-gray-900">{game.time}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <TimerIcon className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-500">Duration</p>
                  <p className="text-gray-900">{game.duration} minutes</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Award className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-500">Skill Level</p>
                  <p className="text-gray-900 capitalize">{game.skill_level}</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <MapPin className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-500">Venue</p>
                  <p className="text-gray-900">{game.venue?.name}</p>
                  {game.venue?.address && (
                    <p className="text-sm text-gray-500">{game.venue.address}</p>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Users className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-500">Players</p>
                  <p className="text-gray-900">
                    {game.current_players} / {game.max_players} players joined
                  </p>
                </div>
              </div>
            </div>

            {game.description && (
              <div className="pt-4 border-t border-gray-200">
                <h3 className="font-medium text-gray-900 mb-2">Description</h3>
                <p className="text-gray-600">{game.description}</p>
              </div>
            )}

            {game.rules && (
              <div className="pt-4 border-t border-gray-200">
                <h3 className="font-medium text-gray-900 mb-2">Rules</h3>
                <p className="text-gray-600">{game.rules}</p>
              </div>
            )}
          </div>

          {/* Actions Section */}
          <div className="bg-gray-50 p-6 rounded-lg">
            <h3 className="font-medium text-gray-900 mb-4">
              {isParticipating ? 'Game Actions' : 'Join Game'}
            </h3>
            <div className="space-y-3">
              {isParticipating ? (
                <>
                  <Button
                    onClick={() => navigate(`/games/${game.id}/group`)}
                    className="w-full bg-emerald-500 hover:bg-emerald-600"
                  >
                    View Group Chat
                  </Button>
                  <p className="text-sm text-gray-500 text-center">
                    Chat with other players and get updates
                  </p>
                </>
              ) : isOrganizer ? (
                isGameOrganizer ? (
                  <>
                    <Button
                      onClick={() => navigate(`/games/${game.id}/group`)}
                      className="w-full bg-emerald-500 hover:bg-emerald-600"
                    >
                      Manage Game
                    </Button>
                    <p className="text-sm text-gray-500 text-center">
                      Access game management tools and participant list
                    </p>
                  </>
                ) : (
                  <p className="text-sm text-gray-500 text-center">
                    As an organizer, you can only manage your own games
                  </p>
                )
              ) : (
                <>
                  <JoinGameButton
                    gameId={game.id}
                    currentPlayers={game.current_players}
                    maxPlayers={game.max_players}
                    fullWidth
                  />
                  <p className="text-sm text-gray-500 text-center">
                    Join to participate in the game and chat with other players
                  </p>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}