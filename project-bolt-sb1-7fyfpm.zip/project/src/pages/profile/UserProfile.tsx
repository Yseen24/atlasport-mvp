import React from 'react';
import { useAuthStore } from '../../store/authStore';
import { useNavigate, useLocation } from 'react-router-dom';
import { User, Mail, Phone, Calendar } from 'lucide-react';
import { format } from 'date-fns';
import { Button } from '../../components/ui/Button';
import { Alert } from '../../components/ui/Alert';

export function UserProfile() {
  const { user } = useAuthStore();
  const navigate = useNavigate();
  const location = useLocation();
  const welcomeMessage = location.state?.message;

  if (!user) {
    navigate('/login');
    return null;
  }

  // Format date safely
  const formatCreatedAt = () => {
    try {
      if (!user.created_at) return 'Recently joined';
      return format(new Date(user.created_at), 'MMMM d, yyyy');
    } catch (error) {
      return 'Recently joined';
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {welcomeMessage && (
        <Alert
          type="success"
          message={welcomeMessage}
        />
      )}

      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        {/* Profile Header */}
        <div className="p-6 border-b border-gray-200">
          <h1 className="text-2xl font-bold text-gray-900">Your Profile</h1>
          <p className="mt-1 text-gray-600">
            Manage your account information and preferences
          </p>
        </div>

        {/* Profile Information */}
        <div className="p-6 space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            {/* Basic Information */}
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <User className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-500">Name</p>
                  <p className="text-gray-900">{user.name}</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Mail className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-500">Email</p>
                  <p className="text-gray-900">{user.email}</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Phone className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-500">Phone</p>
                  <p className="text-gray-900">{user.phone}</p>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <Calendar className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-500">Member Since</p>
                  <p className="text-gray-900">{formatCreatedAt()}</p>
                </div>
              </div>
            </div>

            {/* Account Status */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <h3 className="font-medium text-gray-900">Account Status</h3>
              <div className="mt-2 space-y-3">
                <div>
                  <p className="text-sm font-medium text-gray-500">Role</p>
                  <p className="text-gray-900 capitalize">{user.role.toLowerCase()}</p>
                </div>
                {user.role === 'ORGANIZER' && (
                  <div>
                    <p className="text-sm font-medium text-gray-500">Organizer Status</p>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      user.organizer_status === 'APPROVED' 
                        ? 'bg-green-100 text-green-800'
                        : user.organizer_status === 'PENDING'
                        ? 'bg-yellow-100 text-yellow-800'
                        : 'bg-gray-100 text-gray-800'
                    }`}>
                      {user.organizer_status.replace('_', ' ')}
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex justify-end space-x-4 pt-6 border-t border-gray-200">
            <Button
              variant="outline"
              onClick={() => navigate('/games')}
            >
              Browse Games
            </Button>
            <Button
              onClick={() => navigate(`/${user.role.toLowerCase()}/dashboard`)}
            >
              Go to Dashboard
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}