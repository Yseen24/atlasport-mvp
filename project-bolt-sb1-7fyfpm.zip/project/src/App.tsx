import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { Layout } from './components/layout/Layout';
import { ProtectedRoute } from './components/auth/ProtectedRoute';
import { GamesPage } from './pages/Games';
import { GameDetails } from './pages/event/GameDetails';
import { GameManagement } from './pages/event/GameManagement';
import { PlayerDashboard } from './pages/player/Dashboard';
import { OrganizerDashboard } from './pages/organizer/Dashboard';
import { AdminDashboard } from './pages/admin/Dashboard';
import { CreateGame } from './pages/organizer/CreateGame';
import { CreateVenue } from './pages/admin/venues/CreateVenue';
import { LoginPage } from './pages/auth/Login';
import { RegisterPage } from './pages/auth/Register';
import { ForgotPasswordPage } from './pages/auth/ForgotPassword';
import { ResetPasswordPage } from './pages/auth/ResetPassword';
import { UnauthorizedPage } from './pages/auth/Unauthorized';
import { UserProfile } from './pages/profile/UserProfile';
import { EventGroup } from './pages/event/EventGroup';
import { Toaster } from 'react-hot-toast';

export default function App() {
  return (
    <Router>
      <AuthProvider>
        <Layout>
          <Routes>
            {/* Public Routes */}
            <Route path="/" element={
              <div className="text-center">
                <h1 className="text-4xl font-bold text-gray-900 mb-8">
                  Welcome to Atlasport
                </h1>
                <p className="text-xl text-gray-600 max-w-2xl mx-auto">
                  Join the community of sports enthusiasts. Find games, organize matches, 
                  and connect with players in your area.
                </p>
              </div>
            } />
            
            <Route path="/games" element={<GamesPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/forgot-password" element={<ForgotPasswordPage />} />
            <Route path="/reset-password" element={<ResetPasswordPage />} />
            <Route path="/unauthorized" element={<UnauthorizedPage />} />

            {/* Protected Routes */}
            <Route path="/games/:gameId" element={
              <ProtectedRoute>
                <GameDetails />
              </ProtectedRoute>
            } />

            <Route path="/games/:gameId/group" element={
              <ProtectedRoute>
                <EventGroup />
              </ProtectedRoute>
            } />

            <Route path="/games/:gameId/manage" element={
              <ProtectedRoute allowedRoles={['ORGANIZER']}>
                <GameManagement />
              </ProtectedRoute>
            } />

            <Route path="/profile" element={
              <ProtectedRoute>
                <UserProfile />
              </ProtectedRoute>
            } />

            <Route path="/player/dashboard" element={
              <ProtectedRoute allowedRoles={['PLAYER']}>
                <PlayerDashboard />
              </ProtectedRoute>
            } />

            <Route path="/organizer/dashboard" element={
              <ProtectedRoute allowedRoles={['ORGANIZER']}>
                <OrganizerDashboard />
              </ProtectedRoute>
            } />

            <Route path="/organizer/games/create" element={
              <ProtectedRoute allowedRoles={['ORGANIZER']}>
                <CreateGame />
              </ProtectedRoute>
            } />

            <Route path="/admin/dashboard" element={
              <ProtectedRoute allowedRoles={['ADMIN']}>
                <AdminDashboard />
              </ProtectedRoute>
            } />

            <Route path="/admin/venues/create" element={
              <ProtectedRoute allowedRoles={['ADMIN']}>
                <CreateVenue />
              </ProtectedRoute>
            } />
          </Routes>
        </Layout>
        <Toaster position="top-right" />
      </AuthProvider>
    </Router>
  );
}