import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export function useGameParticipation(gameId: string, userId?: string) {
  const [isParticipating, setIsParticipating] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const checkParticipation = async () => {
      if (!userId) {
        setIsParticipating(false);
        setIsLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('game_participants')
          .select('id')
          .eq('game_id', gameId)
          .eq('player_id', userId)
          .maybeSingle();

        if (error) throw error;
        setIsParticipating(!!data);
      } catch (err) {
        console.error('Error checking participation:', err);
      } finally {
        setIsLoading(false);
      }
    };

    checkParticipation();

    // Subscribe to changes
    const subscription = supabase
      .channel(`game_participants:${gameId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'game_participants',
        filter: `game_id=eq.${gameId}`
      }, () => {
        checkParticipation();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [gameId, userId]);

  return { isParticipating, isLoading };
}