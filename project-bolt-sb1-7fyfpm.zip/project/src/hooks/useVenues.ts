import { useState } from 'react';
import { VenueService } from '../lib/services/venue.service';
import type { VenueFormData } from '../types';

export function useVenues() {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const createVenue = async (formData: VenueFormData) => {
    try {
      setIsLoading(true);
      setError(null);

      const { error: venueError } = await VenueService.createVenue(formData);
      
      if (venueError) {
        throw venueError;
      }

      return { error: null };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to create venue';
      setError(message);
      return { error: message };
    } finally {
      setIsLoading(false);
    }
  };

  return {
    createVenue,
    isLoading,
    error
  };
}