import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { toast } from 'react-hot-toast';
import type { EventParticipant, EventMessage } from '../types/event';

export function useEventGroup(gameId: string) {
  const [participants, setParticipants] = useState<EventParticipant[]>([]);
  const [messages, setMessages] = useState<EventMessage[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchEventData = async () => {
      try {
        setIsLoading(true);
        setError(null);

        // Fetch game details to get organizer_id
        const { data: game, error: gameError } = await supabase
          .from('games')
          .select('organizer_id')
          .eq('id', gameId)
          .single();

        if (gameError) throw gameError;

        // Fetch participants
        const { data: participantsData, error: participantsError } = await supabase
          .from('game_participants')
          .select(`
            *,
            user:profiles(id, name, email, role)
          `)
          .eq('game_id', gameId);

        if (participantsError) throw participantsError;

        // Fetch messages
        const { data: messagesData, error: messagesError } = await supabase
          .from('messages')
          .select(`
            *,
            user:profiles(id, name)
          `)
          .eq('game_id', gameId)
          .order('created_at', { ascending: true });

        if (messagesError) throw messagesError;

        // Process participants to include organizer status
        const processedParticipants = participantsData?.map(p => ({
          ...p,
          isOrganizer: p.user.id === game.organizer_id
        })) || [];

        setParticipants(processedParticipants);
        setMessages(messagesData || []);
      } catch (err) {
        console.error('Error fetching event data:', err);
        const message = err instanceof Error ? err.message : 'Failed to load event data';
        setError(message);
        toast.error(message);
      } finally {
        setIsLoading(false);
      }
    };

    if (gameId) {
      fetchEventData();

      // Set up real-time subscriptions
      const participantsSubscription = supabase
        .channel('game_participants')
        .on('postgres_changes', {
          event: '*',
          schema: 'public',
          table: 'game_participants',
          filter: `game_id=eq.${gameId}`
        }, () => {
          fetchEventData();
        })
        .subscribe();

      const messagesSubscription = supabase
        .channel('messages')
        .on('postgres_changes', {
          event: 'INSERT',
          schema: 'public',
          table: 'messages',
          filter: `game_id=eq.${gameId}`
        }, async (payload) => {
          // Fetch the complete message with user data
          const { data: newMessage, error: messageError } = await supabase
            .from('messages')
            .select(`
              *,
              user:profiles(id, name)
            `)
            .eq('id', payload.new.id)
            .single();

          if (!messageError && newMessage) {
            setMessages(prev => [...prev, newMessage]);
          }
        })
        .subscribe();

      return () => {
        participantsSubscription.unsubscribe();
        messagesSubscription.unsubscribe();
      };
    }
  }, [gameId]);

  // Get player count (excluding organizer)
  const playerCount = participants.filter(p => !p.isOrganizer).length;

  return {
    participants,
    messages,
    playerCount,
    isLoading,
    error
  };
}