import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { toast } from 'react-hot-toast';
import type { Game } from '../types';

export function useGameDetails(gameId: string | undefined) {
  const [game, setGame] = useState<Game | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchGameDetails = async () => {
      try {
        if (!gameId) {
          setError('Invalid game ID');
          return;
        }

        setIsLoading(true);
        setError(null);

        const { data, error: gameError } = await supabase
          .from('games')
          .select(`
            *,
            venue:venues(name, address),
            organizer:profiles(name, email, phone)
          `)
          .eq('id', gameId)
          .single();

        if (gameError) throw gameError;
        if (!data) throw new Error('Game not found');

        setGame(data);
      } catch (err) {
        console.error('Error fetching game details:', err);
        const message = err instanceof Error ? err.message : 'Failed to load game details';
        setError(message);
        toast.error(message);
      } finally {
        setIsLoading(false);
      }
    };

    if (gameId) {
      fetchGameDetails();

      // Subscribe to game changes
      const subscription = supabase
        .channel(`game_${gameId}`)
        .on('postgres_changes', {
          event: '*',
          schema: 'public',
          table: 'games',
          filter: `id=eq.${gameId}`
        }, () => {
          fetchGameDetails();
        })
        .subscribe();

      return () => {
        subscription.unsubscribe();
      };
    }
  }, [gameId]);

  return { game, isLoading, error };
}