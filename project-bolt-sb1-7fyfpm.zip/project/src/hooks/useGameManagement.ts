import { useState } from 'react';
import { supabase } from '../lib/supabase';
import { toast } from 'react-hot-toast';
import type { Game } from '../types';

export function useGameManagement(gameId: string) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const updateGameDetails = async (data: Partial<Game>) => {
    try {
      setIsLoading(true);
      setError(null);

      const { error: updateError } = await supabase
        .from('games')
        .update({
          sport_type: data.sport_type,
          date: data.date,
          time: data.time,
          max_players: data.max_players,
          price_per_player: data.price_per_player,
          updated_at: new Date().toISOString()
        })
        .eq('id', gameId);

      if (updateError) throw updateError;

      // Add system message about update
      await supabase
        .from('messages')
        .insert({
          game_id: gameId,
          content: 'Game details have been updated by the organizer',
          type: 'ANNOUNCEMENT'
        });

      return { error: null };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to update game';
      setError(message);
      return { error: message };
    } finally {
      setIsLoading(false);
    }
  };

  const cancelGame = async (reason: string) => {
    try {
      setIsLoading(true);
      setError(null);

      const { error: cancelError } = await supabase
        .from('games')
        .update({ 
          status: 'CANCELLED',
          updated_at: new Date().toISOString()
        })
        .eq('id', gameId);

      if (cancelError) throw cancelError;

      // Add cancellation message
      await supabase
        .from('messages')
        .insert({
          game_id: gameId,
          content: `Game has been cancelled. Reason: ${reason}`,
          type: 'ANNOUNCEMENT'
        });

      return { error: null };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to cancel game';
      setError(message);
      return { error: message };
    } finally {
      setIsLoading(false);
    }
  };

  const removeParticipant = async (participantId: string) => {
    try {
      setIsLoading(true);
      setError(null);

      const { error: removeError } = await supabase
        .from('game_participants')
        .delete()
        .eq('id', participantId)
        .eq('game_id', gameId);

      if (removeError) throw removeError;

      // Update current players count
      await supabase
        .from('games')
        .update({ 
          current_players: supabase.raw('current_players - 1')
        })
        .eq('id', gameId);

      return { error: null };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to remove participant';
      setError(message);
      return { error: message };
    } finally {
      setIsLoading(false);
    }
  };

  const updateParticipantStatus = async (participantId: string, status: 'CONFIRMED' | 'DECLINED') => {
    try {
      setIsLoading(true);
      setError(null);

      const { error: updateError } = await supabase
        .from('game_participants')
        .update({ status })
        .eq('id', participantId)
        .eq('game_id', gameId);

      if (updateError) throw updateError;

      // Add status update message
      await supabase
        .from('messages')
        .insert({
          game_id: gameId,
          content: `A participant's status has been updated to ${status.toLowerCase()}`,
          type: 'ANNOUNCEMENT'
        });

      return { error: null };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to update participant status';
      setError(message);
      return { error: message };
    } finally {
      setIsLoading(false);
    }
  };

  return {
    isLoading,
    error,
    updateGameDetails,
    cancelGame,
    removeParticipant,
    updateParticipantStatus
  };
}