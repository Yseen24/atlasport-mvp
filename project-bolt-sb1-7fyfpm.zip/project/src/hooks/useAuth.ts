import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { authService } from '../lib/services/auth.service';
import { toast } from 'react-hot-toast';
import type { RegisterFormData } from '../types';
import { isAuthError } from '../lib/utils/auth-errors';

export function useAuth() {
  const navigate = useNavigate();
  const { setUser } = useAuthStore();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const signUp = async (formData: RegisterFormData) => {
    try {
      setIsLoading(true);
      setError(null);

      const { profile } = await authService.signUp(formData);

      if (!profile) {
        throw new Error('Failed to create user profile');
      }

      setUser(profile);
      toast.success('Account created successfully!');
      return { success: true, error: null };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Registration failed';
      setError(message);
      
      // Show different toast for auth errors vs other errors
      if (isAuthError(err)) {
        toast.error('This email is already registered');
      } else {
        toast.error(message);
      }
      
      return { success: false, error: message };
    } finally {
      setIsLoading(false);
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      setIsLoading(true);
      setError(null);

      const { profile } = await authService.signIn(email, password);

      if (!profile) {
        throw new Error('User profile not found');
      }

      setUser(profile);
      toast.success('Welcome back!');
      return { success: true, error: null };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Sign in failed';
      setError(message);
      toast.error(message);
      return { success: false, error: message };
    } finally {
      setIsLoading(false);
    }
  };

  const signOut = async () => {
    try {
      setIsLoading(true);
      await authService.signOut();
      setUser(null);
      navigate('/login');
      toast.success('Signed out successfully');
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Sign out failed';
      setError(message);
      toast.error(message);
    } finally {
      setIsLoading(false);
    }
  };

  return {
    signIn,
    signUp,
    signOut,
    isLoading,
    error
  };
}