import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { toast } from 'react-hot-toast';
import type { Game } from '../types';

export function useOrganizerGames(organizerId: string) {
  const [games, setGames] = useState<Game[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchGames = async () => {
      try {
        setIsLoading(true);
        setError(null);

        const { data, error: gamesError } = await supabase
          .from('games')
          .select(`
            *,
            venue:venues (
              name
            ),
            current_players
          `)
          .eq('organizer_id', organizerId)
          .order('date', { ascending: true });

        if (gamesError) throw gamesError;
        setGames(data || []);
      } catch (err) {
        console.error('Error fetching organizer games:', err);
        const message = err instanceof Error ? err.message : 'Failed to load games';
        setError(message);
        toast.error(message);
      } finally {
        setIsLoading(false);
      }
    };

    if (organizerId) {
      fetchGames();

      // Subscribe to changes
      const subscription = supabase
        .channel('games_changes')
        .on('postgres_changes', {
          event: '*',
          schema: 'public',
          table: 'games',
          filter: `organizer_id=eq.${organizerId}`
        }, () => {
          fetchGames();
        })
        .subscribe();

      return () => {
        subscription.unsubscribe();
      };
    }
  }, [organizerId]);

  return { games, isLoading, error };
}