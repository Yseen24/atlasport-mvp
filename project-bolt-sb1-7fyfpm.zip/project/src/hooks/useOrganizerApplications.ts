import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { toast } from 'react-hot-toast';

interface OrganizerApplication {
  id: string;
  name: string;
  email: string;
  phone: string;
  created_at: string;
}

export function useOrganizerApplications() {
  const [applications, setApplications] = useState<OrganizerApplication[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchApplications = async () => {
    try {
      setIsLoading(true);
      const { data, error: fetchError } = await supabase
        .from('profiles')
        .select('id, name, email, phone, created_at')
        .eq('role', 'ORGANIZER')
        .eq('organizer_status', 'PENDING')
        .order('created_at', { ascending: false });

      if (fetchError) throw fetchError;
      setApplications(data || []);
    } catch (err) {
      console.error('Error fetching applications:', err);
      setError('Failed to load applications');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchApplications();
  }, []);

  const approveOrganizer = async (userId: string) => {
    try {
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ organizer_status: 'APPROVED' })
        .eq('id', userId);

      if (updateError) throw updateError;
      
      toast.success('Organizer approved successfully');
      await fetchApplications();
      return { error: null };
    } catch (err) {
      console.error('Error approving organizer:', err);
      const message = err instanceof Error ? err.message : 'Failed to approve organizer';
      toast.error(message);
      return { error: message };
    }
  };

  const rejectOrganizer = async (userId: string) => {
    try {
      const { error: updateError } = await supabase
        .from('profiles')
        .update({ 
          organizer_status: 'NOT_APPLIED',
          role: 'PLAYER'
        })
        .eq('id', userId);

      if (updateError) throw updateError;
      
      toast.success('Organizer application rejected');
      await fetchApplications();
      return { error: null };
    } catch (err) {
      console.error('Error rejecting organizer:', err);
      const message = err instanceof Error ? err.message : 'Failed to reject organizer';
      toast.error(message);
      return { error: message };
    }
  };

  return {
    applications,
    isLoading,
    error,
    approveOrganizer,
    rejectOrganizer,
    refresh: fetchApplications
  };
}