import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { toast } from 'react-hot-toast';

export function useEventAccess(gameId: string, userId: string | undefined) {
  const [hasAccess, setHasAccess] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const checkAccess = async () => {
      try {
        if (!userId) {
          setHasAccess(false);
          return;
        }

        setIsLoading(true);
        setError(null);

        // Check if user is organizer or participant
        const { data: participant, error: participantError } = await supabase
          .from('game_participants')
          .select('id')
          .eq('game_id', gameId)
          .eq('player_id', userId)
          .maybeSingle();

        if (participantError) throw participantError;

        // Check if user is organizer
        const { data: game, error: gameError } = await supabase
          .from('games')
          .select('organizer_id')
          .eq('id', gameId)
          .single();

        if (gameError) throw gameError;

        setHasAccess(!!participant || game.organizer_id === userId);
      } catch (err) {
        console.error('Error checking event access:', err);
        const message = err instanceof Error ? err.message : 'Failed to verify access';
        setError(message);
        toast.error(message);
      } finally {
        setIsLoading(false);
      }
    };

    checkAccess();
  }, [gameId, userId]);

  return { hasAccess, isLoading, error };
}