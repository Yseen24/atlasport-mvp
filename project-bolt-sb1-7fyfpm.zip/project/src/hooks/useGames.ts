import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { toast } from 'react-hot-toast';
import type { Game } from '../types';

export function useGames() {
  const [games, setGames] = useState<Game[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchGames = async () => {
      try {
        const { data, error: supabaseError } = await supabase
          .from('games')
          .select(`
            *,
            venue:venues(name),
            organizer:profiles(name)
          `)
          .order('date', { ascending: true });

        if (supabaseError) throw supabaseError;

        setGames(data || []);
        setIsLoading(false);
      } catch (err) {
        setError('Failed to load games');
        setIsLoading(false);
      }
    };

    fetchGames();
  }, []);

  const joinGame = async (gameId: string, playerId: string) => {
    try {
      const { data, error: joinError } = await supabase.rpc('join_game', {
        p_game_id: gameId,
        p_player_id: playerId
      });

      if (joinError) {
        toast.error(joinError.message);
        return { error: joinError.message };
      }

      if (data?.error) {
        toast.error(data.error);
        return { error: data.error };
      }

      // Refresh games list
      const { data: updatedGames, error: gamesError } = await supabase
        .from('games')
        .select(`
          *,
          venue:venues(name),
          organizer:profiles(name)
        `)
        .order('date', { ascending: true });

      if (gamesError) throw gamesError;
      setGames(updatedGames || []);

      toast.success('Successfully joined the game!');
      return { error: null };
    } catch (err) {
      console.error('Error joining game:', err);
      const message = err instanceof Error ? err.message : 'Failed to join game';
      toast.error(message);
      return { error: message };
    }
  };

  return { games, isLoading, error, joinGame };
}