import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { toast } from 'react-hot-toast';
import type { EventReminder } from '../types/event';

export function useEventReminders(gameId: string, userId: string) {
  const [reminders, setReminders] = useState<EventReminder[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchReminders = async () => {
      try {
        setIsLoading(true);
        setError(null);

        const { data, error: remindersError } = await supabase
          .from('event_reminders')
          .select('*')
          .eq('game_id', gameId)
          .eq('user_id', userId);

        if (remindersError) throw remindersError;
        setReminders(data || []);
      } catch (err) {
        console.error('Error fetching reminders:', err);
        const message = err instanceof Error ? err.message : 'Failed to load reminders';
        setError(message);
      } finally {
        setIsLoading(false);
      }
    };

    if (gameId && userId) {
      fetchReminders();
    }
  }, [gameId, userId]);

  const setReminder = async (reminderTime: string) => {
    try {
      const { error: reminderError } = await supabase
        .from('event_reminders')
        .upsert({
          game_id: gameId,
          user_id: userId,
          reminder_time: reminderTime,
          is_enabled: true
        });

      if (reminderError) throw reminderError;
      
      toast.success('Reminder set successfully');
      
      // Refresh reminders
      const { data: updatedReminders } = await supabase
        .from('event_reminders')
        .select('*')
        .eq('game_id', gameId)
        .eq('user_id', userId);
        
      setReminders(updatedReminders || []);
    } catch (err) {
      console.error('Error setting reminder:', err);
      const message = err instanceof Error ? err.message : 'Failed to set reminder';
      toast.error(message);
      throw err;
    }
  };

  const removeReminder = async (reminderId: string) => {
    try {
      const { error: deleteError } = await supabase
        .from('event_reminders')
        .delete()
        .eq('id', reminderId)
        .eq('user_id', userId);

      if (deleteError) throw deleteError;
      
      toast.success('Reminder removed');
      setReminders(reminders.filter(r => r.id !== reminderId));
    } catch (err) {
      console.error('Error removing reminder:', err);
      const message = err instanceof Error ? err.message : 'Failed to remove reminder';
      toast.error(message);
      throw err;
    }
  };

  return {
    reminders,
    isLoading,
    error,
    setReminder,
    removeReminder
  };
}