import { useState, useEffect } from 'react';
import { GameService } from '../lib/services/game.service';
import { toast } from 'react-hot-toast';
import type { Game, Sport_Type, Venue } from '../types';

// Create a type for the form data
type CreateGameData = {
  title: string;
  sport_Type: Sport_Type; // Changed from sport_Type to match your form
  skill_Level: string;
  date: string;
  time: string;
  duration: number;
  venueId: string;
  organizerId: string;
  maxPlayers: number;
  pricePerPlayer: number;
  description: string;
  rules: string;
};

export function useGameForm() {
  const [venues, setVenues] = useState<Venue[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchVenues = async () => {
    try {
      setIsLoading(true);
      const { data, error: venuesError } = await GameService.getVenues();
      
      if (venuesError) throw venuesError;
      
      setVenues(data as Venue[] || []);
      return { data, error: null };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to fetch venues';
      setError(message);
      toast.error(message);
      return { data: null, error: message };
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchVenues();
  }, []);

  const createGame = async (formData: CreateGameData) => {
    try {
      setIsLoading(true);
      setError(null);

      // Format the data to match database schema
      const gameData = {
        title: formData.title,
        sport_type: formData.sport_Type, // Removed redundant cast since type is already SportType
        skill_level: formData.skill_Level,
        date: formData.date,
        time: formData.time,
        duration: formData.duration,
        venue_id: formData.venueId,
        organizer_id: formData.organizerId,
        max_players: formData.maxPlayers,
        current_players: 0,
        price_per_player: formData.pricePerPlayer,
        description: formData.description,
        rules: formData.rules,
        status: 'UPCOMING' as const
      } satisfies Partial<Game>;
      
      const { data, error: gameError } = await GameService.createGame(gameData);
      
      if (gameError) {
        setError(gameError.toString());
        return { data: null, error: gameError };
      }

      toast.success('Game created successfully!');
      return { data, error: null };
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to create game';
      setError(message);
      toast.error(message);
      return { data: null, error: message };
    } finally {
      setIsLoading(false);
    }
  };

  return {
    venues,
    isLoading,
    error,
    fetchVenues,
    createGame
  };
}