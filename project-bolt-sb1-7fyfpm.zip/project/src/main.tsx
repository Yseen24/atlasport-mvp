import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App';
import './index.css';
import { AdminService } from './lib/services/admin.service';

// Create default admin account
AdminService.createDefaultAdmin()
  .then(({ email, password }) => {
    console.info('Admin credentials:', { email, password });
  })
  .catch(console.error);

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
);