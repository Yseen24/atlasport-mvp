import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { Button } from '../ui/Button';
import { useDebounce } from '../../hooks/useDebounce';
import { supabase } from '../../lib/supabase';
import { toast } from 'react-hot-toast';
import { UserPlus, Loader2 } from 'lucide-react';
import { JoinGameConfirmation } from './JoinGameConfirmation';
import { useGameDetails } from '../../hooks/useGameDetails';

interface JoinGameButtonProps {
  gameId: string;
  currentPlayers: number;
  maxPlayers: number;
  onSuccess?: () => void;
  className?: string;
  fullWidth?: boolean;
}

export function JoinGameButton({
  gameId,
  currentPlayers,
  maxPlayers,
  onSuccess,
  className,
  fullWidth
}: JoinGameButtonProps) {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuthStore();
  const [isJoining, setIsJoining] = React.useState(false);
  const [showConfirmation, setShowConfirmation] = React.useState(false);
  const { game } = useGameDetails(gameId);

  const handleJoinGame = async () => {
    try {
      if (!user) {
        navigate('/login', {
          state: { from: location }
        });
        return;
      }

      setIsJoining(true);

      // Join the game with CONFIRMED status
      const { error: joinError } = await supabase.rpc('join_game', {
        p_game_id: gameId,
        p_player_id: user.id
      });

      if (joinError) throw joinError;

      // Send announcement message
      await supabase.from('messages').insert({
        game_id: gameId,
        user_id: user.id,
        content: `${user.name} joined the game`,
        type: 'ANNOUNCEMENT'
      });

      toast.success('Successfully joined the game!');
      onSuccess?.();
      setShowConfirmation(false);
      navigate(`/games/${gameId}/group`);
    } catch (err) {
      console.error('Error joining game:', err);
      const message = err instanceof Error ? err.message : 'Failed to join game';
      toast.error(message);
    } finally {
      setIsJoining(false);
    }
  };

  const handleClick = useDebounce(() => {
    if (!user) {
      navigate('/login', {
        state: { from: location }
      });
      return;
    }
    setShowConfirmation(true);
  }, 300);

  const isFull = currentPlayers >= maxPlayers;

  return (
    <>
      <Button
        onClick={handleClick}
        disabled={isJoining || isFull}
        className={className}
        fullWidth={fullWidth}
        aria-label="Join game"
      >
        {isJoining ? (
          <>
            <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            Joining...
          </>
        ) : isFull ? (
          'Game Full'
        ) : (
          <>
            <UserPlus className="w-4 h-4 mr-2" />
            Join Game
          </>
        )}
      </Button>

      {game && (
        <JoinGameConfirmation
          game={game}
          isOpen={showConfirmation}
          onClose={() => setShowConfirmation(false)}
          onConfirm={handleJoinGame}
          isLoading={isJoining}
        />
      )}
    </>
  );
}