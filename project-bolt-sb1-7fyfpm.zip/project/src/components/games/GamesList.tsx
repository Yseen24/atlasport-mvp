import React from 'react';
import { GameCard } from './GameCard';
import { useGames } from '../../hooks/useGames';
import { useAuthStore } from '../../store/authStore';
import { Filter } from 'lucide-react';

export function GamesList() {
  const { games, isLoading, error, joinGame } = useGames();
  const { user } = useAuthStore();
  const [filters, setFilters] = React.useState({
    sport: 'all',
    date: 'upcoming'
  });

  const handleJoinGame = async (gameId: string) => {
    if (!user) {
      // TODO: Show login prompt
      return;
    }

    const { error: joinError } = await joinGame(gameId, user.id);
    if (joinError) {
      console.error('Error joining game:', joinError);
      // TODO: Show error notification
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-[200px]">
        <div className="text-gray-600">Loading games...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-md p-4 text-red-600">
        Error loading games: {error}
      </div>
    );
  }

  const filteredGames = games.filter(game => {
    if (filters.sport !== 'all' && game.sport_type !== filters.sport) return false;
    if (filters.date === 'upcoming' && new Date(game.date) < new Date()) return false;
    return true;
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4 p-4 bg-white rounded-lg border border-gray-200">
        <Filter className="w-5 h-5 text-gray-500" />
        <select
          value={filters.sport}
          onChange={(e) => setFilters(prev => ({ ...prev, sport: e.target.value }))}
          className="rounded-md border border-gray-300 px-3 py-1.5 text-sm"
        >
          <option value="all">All Sports</option>
          <option value="Football">Football</option>
          <option value="Basketball">Basketball</option>
          <option value="Volleyball">Volleyball</option>
        </select>
        <select
          value={filters.date}
          onChange={(e) => setFilters(prev => ({ ...prev, date: e.target.value }))}
          className="rounded-md border border-gray-300 px-3 py-1.5 text-sm"
        >
          <option value="upcoming">Upcoming</option>
          <option value="all">All Dates</option>
        </select>
      </div>

      {filteredGames.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg border border-gray-200">
          <p className="text-gray-600">No games found matching your filters.</p>
        </div>
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {filteredGames.map(game => (
            <GameCard key={game.id} game={game} onJoin={handleJoinGame} />
          ))}
        </div>
      )}
    </div>
  );
}