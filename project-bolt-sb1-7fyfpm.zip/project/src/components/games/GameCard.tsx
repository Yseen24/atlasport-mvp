import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { MapPin, Users, Clock, CheckCircle } from 'lucide-react';
import { Alert } from '../ui/Alert';
import { Button } from '../ui/Button';
import { JoinGameButton } from './JoinGameButton';
import { useGameParticipation } from '../../hooks/useGameParticipation';
import type { Game } from '../../types';

interface GameCardProps {
  game: Game;
}

export function GameCard({ game }: GameCardProps) {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [error, setError] = React.useState<string | null>(null);
  const { isParticipating } = useGameParticipation(game.id, user?.id);

  const isOrganizer = user?.role === 'ORGANIZER';
  const isGameOrganizer = user?.id === game.organizer_id;

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6 hover:shadow-md transition-shadow">
      <div className="space-y-4">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-xl font-semibold text-gray-900">{game.sport_type}</h3>
            {isParticipating && (
              <span className="inline-flex items-center text-sm text-emerald-600 mt-1">
                <CheckCircle className="w-4 h-4 mr-1" />
                Participating
              </span>
            )}
          </div>
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            {game.status}
          </span>
        </div>

        <div className="mt-2 space-y-2">
          <div className="flex items-center text-gray-600">
            <Clock className="w-4 h-4 mr-2" />
            <span>{game.time}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <MapPin className="w-4 h-4 mr-2" />
            <span>{game.venue?.name || 'Venue Name'}</span>
          </div>
          <div className="flex items-center text-gray-600">
            <Users className="w-4 h-4 mr-2" />
            <span>{game.current_players - 1}/{game.max_players} players</span>
          </div>
        </div>

        {error && (
          <Alert
            type="error"
            message={error}
          />
        )}
        
        <div className="flex items-center justify-between pt-4 border-t border-gray-100">
          <div className="text-lg font-semibold text-gray-900">
            ${game.price_per_player}
            <span className="text-sm text-gray-500 font-normal">/player</span>
          </div>
          <div className="space-x-2">
            <Button
              variant="outline"
              onClick={() => navigate(`/games/${game.id}`)}
            >
              View Details
            </Button>
            {isParticipating ? (
              <Button
                onClick={() => navigate(`/games/${game.id}/group`)}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                View Group
              </Button>
            ) : isOrganizer ? (
              isGameOrganizer && (
                <Button
                  onClick={() => navigate(`/games/${game.id}/manage`)}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  Manage Game
                </Button>
              )
            ) : (
              <JoinGameButton
                gameId={game.id}
                currentPlayers={game.current_players - 1}
                maxPlayers={game.max_players}
                onSuccess={() => setError(null)}
              />
            )}
          </div>
        </div>
      </div>
    </div>
  );
}