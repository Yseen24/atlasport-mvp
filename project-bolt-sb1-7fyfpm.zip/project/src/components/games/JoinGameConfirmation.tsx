import React from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertCircle, X } from 'lucide-react';
import { Button } from '../ui/Button';
import type { Game } from '../../types';

interface JoinGameConfirmationProps {
  game: Game;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => Promise<void>;
  isLoading: boolean;
}

export function JoinGameConfirmation({
  game,
  isOpen,
  onClose,
  onConfirm,
  isLoading
}: JoinGameConfirmationProps) {
  const [termsAccepted, setTermsAccepted] = React.useState(false);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg max-w-md w-full mx-4 p-6">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Confirm Participation</h3>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-500"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          {/* Game Details */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <h4 className="font-medium text-gray-900 mb-2">Game Details</h4>
            <dl className="space-y-1 text-sm">
              <div className="flex justify-between">
                <dt className="text-gray-500">Sport:</dt>
                <dd className="font-medium">{game.sport_type}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-gray-500">Price:</dt>
                <dd className="font-medium">${game.price_per_player}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-gray-500">Players:</dt>
                <dd className="font-medium">{game.current_players}/{game.max_players}</dd>
              </div>
            </dl>
          </div>

          {/* Payment Terms */}
          <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
            <div className="flex items-start">
              <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5 mr-2 flex-shrink-0" />
              <div className="text-sm text-amber-800">
                <h4 className="font-medium mb-2">Payment Terms</h4>
                <ul className="space-y-1">
                  <li>• Payment must be made in cash</li>
                  <li>• Full amount to be paid to organizer before game starts</li>
                  <li>• No-shows will result in a platform ban</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Terms Acceptance */}
          <label className="flex items-start">
            <input
              type="checkbox"
              checked={termsAccepted}
              onChange={(e) => setTermsAccepted(e.target.checked)}
              className="mt-1 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            />
            <span className="ml-2 text-sm text-gray-600">
              I understand and agree to the payment terms and no-show policy
            </span>
          </label>

          {/* Actions */}
          <div className="flex gap-3 mt-6">
            <Button
              variant="outline"
              onClick={onClose}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={onConfirm}
              disabled={!termsAccepted || isLoading}
              className="flex-1"
            >
              {isLoading ? 'Confirming...' : 'Confirm & Join'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}