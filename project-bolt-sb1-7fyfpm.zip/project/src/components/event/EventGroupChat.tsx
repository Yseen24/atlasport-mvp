import React from 'react';
import { useAuthStore } from '../../store/authStore';
import { Send, AlertCircle, Smile, Reply, MoreVertical, Settings } from 'lucide-react';
import { formatDistanceToNow, parseISO, isValid, format } from 'date-fns';
import { useDebounce } from '../../hooks/useDebounce';
import { Button } from '../ui/Button';
import data from '@emoji-mart/data';
import Picker from '@emoji-mart/react';
import type { EventMessage } from '../../types/event';

interface EventGroupChatProps {
  messages: EventMessage[];
  onSendMessage: (content: string, type: 'CHAT' | 'ANNOUNCEMENT') => Promise<void>;
  isOrganizer?: boolean;
  gameId: string;
}

export function EventGroupChat({ messages, onSendMessage, isOrganizer = false, gameId }: EventGroupChatProps) {
  const { user } = useAuthStore();
  const [message, setMessage] = React.useState('');
  const [isAnnouncement, setIsAnnouncement] = React.useState(false);
  const [isTyping, setIsTyping] = React.useState(false);
  const [showEmojiPicker, setShowEmojiPicker] = React.useState(false);
  const chatRef = React.useRef<HTMLDivElement>(null);
  const emojiButtonRef = React.useRef<HTMLButtonElement>(null);

  // Auto-scroll to bottom when new messages arrive
  React.useEffect(() => {
    if (chatRef.current) {
      chatRef.current.scrollTop = chatRef.current.scrollHeight;
    }
  }, [messages]);

  // Handle typing indicator
  const debouncedTyping = useDebounce(() => {
    setIsTyping(false);
  }, 1000);

  const handleTyping = () => {
    setIsTyping(true);
    debouncedTyping();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    try {
      await onSendMessage(message, isAnnouncement ? 'ANNOUNCEMENT' : 'CHAT');
      setMessage('');
      setIsAnnouncement(false);
      setShowEmojiPicker(false);
    } catch (err) {
      console.error('Error sending message:', err);
    }
  };

  const handleEmojiSelect = (emoji: any) => {
    setMessage(prev => prev + emoji.native);
  };

  // Close emoji picker when clicking outside
  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        showEmojiPicker &&
        emojiButtonRef.current &&
        !emojiButtonRef.current.contains(event.target as Node)
      ) {
        const pickerElement = document.querySelector('.emoji-mart');
        if (pickerElement && !pickerElement.contains(event.target as Node)) {
          setShowEmojiPicker(false);
        }
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [showEmojiPicker]);

  const formatMessageTime = (dateString: string) => {
    try {
      const date = parseISO(dateString);
      if (!isValid(date)) return 'Just now';

      const now = new Date();
      const messageDate = new Date(date);
      const isToday = messageDate.toDateString() === now.toDateString();
      
      if (isToday) {
        return format(date, 'h:mm a');
      }

      return formatDistanceToNow(date, { addSuffix: true });
    } catch (error) {
      return 'Just now';
    }
  };

  return (
    <div className="flex flex-col h-[600px] bg-white rounded-lg border border-gray-200">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center">
        <h3 className="text-lg font-semibold text-gray-900">Group Chat</h3>
        {isOrganizer && (
          <Button
            variant="outline"
            size="sm"
            onClick={() => window.location.href = `/games/${gameId}/manage`}
          >
            <Settings className="w-4 h-4 mr-2" />
            Manage Game
          </Button>
        )}
      </div>

      {/* Rest of the component remains the same */}
    </div>
  );
}