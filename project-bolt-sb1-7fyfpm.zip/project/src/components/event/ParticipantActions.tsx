import React from 'react';
import { Button } from '../ui/Button';
import { CheckCircle, XCircle, UserMinus } from 'lucide-react';
import type { EventParticipant } from '../../types/event';

interface ParticipantActionsProps {
  participant: EventParticipant;
  onConfirm: () => Promise<void>;
  onDecline: () => Promise<void>;
  onRemove: () => Promise<void>;
  isLoading?: boolean;
}

export function ParticipantActions({
  participant,
  onConfirm,
  onDecline,
  onRemove,
  isLoading = false
}: ParticipantActionsProps) {
  return (
    <div className="flex items-center space-x-2">
      <Button
        variant="outline"
        size="sm"
        onClick={onConfirm}
        disabled={participant.status === 'CONFIRMED' || isLoading}
        className="text-green-600 hover:text-green-700"
      >
        <CheckCircle className="w-4 h-4 mr-1" />
        Confirm
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onDecline}
        disabled={participant.status === 'DECLINED' || isLoading}
        className="text-red-600 hover:text-red-700"
      >
        <XCircle className="w-4 h-4 mr-1" />
        Decline
      </Button>

      <Button
        variant="outline"
        size="sm"
        onClick={onRemove}
        disabled={isLoading}
        className="text-gray-600 hover:text-gray-700"
      >
        <UserMinus className="w-4 h-4" />
      </Button>
    </div>
  );
}