import React from 'react';
import { useAuthStore } from '../../store/authStore';
import { Button } from '../ui/Button';
import { Users, UserMinus, CheckCircle, XCircle, Clock, Crown } from 'lucide-react';
import type { EventParticipant } from '../../types/event';

interface ParticipantManagementProps {
  participants: EventParticipant[];
  organizerId: string;
  onRemoveParticipant: (participantId: string) => Promise<void>;
  onUpdateStatus: (participantId: string, status: string) => Promise<void>;
  isLoading?: boolean;
}

export function ParticipantManagement({
  participants,
  organizerId,
  onRemoveParticipant,
  onUpdateStatus,
  isLoading = false
}: ParticipantManagementProps) {
  const { user } = useAuthStore();

  // Separate organizer and players
  const organizer = participants.find(p => p.userId === organizerId);
  const players = participants.filter(p => p.userId !== organizerId);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'CONFIRMED':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'DECLINED':
        return <XCircle className="w-5 h-5 text-red-500" />;
      default:
        return <Clock className="w-5 h-5 text-amber-500" />;
    }
  };

  return (
    <div className="space-y-4">
      {/* Organizer Section */}
      {organizer && (
        <div className="bg-blue-50 p-4 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Crown className="w-5 h-5 text-amber-500" />
              <div>
                <p className="font-medium text-gray-900">{organizer.user.name}</p>
                <p className="text-sm text-gray-500">Organizer</p>
              </div>
            </div>
            {getStatusIcon(organizer.status)}
          </div>
        </div>
      )}

      {/* Players Section */}
      <div className="divide-y divide-gray-200">
        {players.map((participant) => (
          <div key={participant.id} className="py-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-900">{participant.user.name}</p>
                <p className="text-sm text-gray-500">{participant.user.email}</p>
              </div>
              <div className="flex items-center space-x-2">
                {participant.user.id !== user?.id && (
                  <>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onUpdateStatus(participant.id, 'CONFIRMED')}
                      disabled={participant.status === 'CONFIRMED' || isLoading}
                    >
                      Confirm
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onUpdateStatus(participant.id, 'DECLINED')}
                      disabled={participant.status === 'DECLINED' || isLoading}
                    >
                      Decline
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => onRemoveParticipant(participant.id)}
                      disabled={isLoading}
                      className="text-red-600 hover:text-red-700"
                    >
                      <UserMinus className="w-4 h-4" />
                    </Button>
                  </>
                )}
                {getStatusIcon(participant.status)}
              </div>
            </div>
          </div>
        ))}

        {players.length === 0 && (
          <div className="py-8 text-center text-gray-500">
            No players have joined yet
          </div>
        )}
      </div>
    </div>
  );
}