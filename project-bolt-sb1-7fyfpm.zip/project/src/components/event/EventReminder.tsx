import React from 'react';
import { format } from 'date-fns';
import { Bell, BellOff, Trash2 } from 'lucide-react';
import { Button } from '../ui/Button';
import type { EventReminder as EventReminderType } from '../../types/event';

interface EventReminderProps {
  reminder?: EventReminderType;
  onSetReminder: (time: string) => Promise<void>;
  onRemoveReminder: (id: string) => Promise<void>;
}

export function EventReminder({ reminder, onSetReminder, onRemoveReminder }: EventReminderProps) {
  const [isSettingReminder, setIsSettingReminder] = React.useState(false);
  const [selectedTime, setSelectedTime] = React.useState('');

  const handleSetReminder = async () => {
    try {
      await onSetReminder(selectedTime);
      setIsSettingReminder(false);
      setSelectedTime('');
    } catch (err) {
      console.error('Error setting reminder:', err);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-medium text-gray-900">Event Reminder</h4>
        {reminder && (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => onRemoveReminder(reminder.id)}
            className="text-red-600 hover:text-red-700"
          >
            <Trash2 className="w-4 h-4" />
          </Button>
        )}
      </div>

      {isSettingReminder ? (
        <div className="space-y-2">
          <input
            type="datetime-local"
            value={selectedTime}
            onChange={(e) => setSelectedTime(e.target.value)}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          />
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsSettingReminder(false)}
            >
              Cancel
            </Button>
            <Button
              size="sm"
              onClick={handleSetReminder}
              disabled={!selectedTime}
            >
              Set Reminder
            </Button>
          </div>
        </div>
      ) : reminder ? (
        <div className="bg-blue-50 p-3 rounded-md">
          <div className="flex items-center text-blue-700">
            <Bell className="w-4 h-4 mr-2" />
            <span className="text-sm">
              Reminder set for {format(new Date(reminder.reminderTime), 'PPp')}
            </span>
          </div>
        </div>
      ) : (
        <Button
          variant="outline"
          onClick={() => setIsSettingReminder(true)}
          className="w-full"
        >
          <BellOff className="w-4 h-4 mr-2" />
          Set Reminder
        </Button>
      )}
    </div>
  );
}