import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '../ui/Button';
import { Alert } from '../ui/Alert';
import { Settings, Users, AlertTriangle } from 'lucide-react';
import type { Game } from '../../types';

interface GameManagementLayoutProps {
  game: Game;
  error?: string | null;
  children: React.ReactNode;
}

export function GameManagementLayout({ game, error, children }: GameManagementLayoutProps) {
  const navigate = useNavigate();

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {error && (
        <Alert type="error" message={error} />
      )}

      <div className="bg-white rounded-lg shadow-sm border border-gray-200">
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Game Management</h1>
              <p className="mt-1 text-sm text-gray-600">
                {game.sport_type} - {game.venue?.name}
              </p>
            </div>
            <Button
              variant="outline"
              onClick={() => navigate(`/games/${game.id}/group`)}
            >
              Back to Group Chat
            </Button>
          </div>
        </div>

        <div className="p-6 space-y-8">
          {children}
        </div>
      </div>
    </div>
  );
}