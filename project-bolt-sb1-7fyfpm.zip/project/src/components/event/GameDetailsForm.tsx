import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { GameSchema } from '../../schemas/game';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import type { Game } from '../../types';

interface GameDetailsFormProps {
  game: Game;
  onSubmit: (data: Partial<Game>) => Promise<void>;
  isLoading?: boolean;
}

export function GameDetailsForm({ game, onSubmit, isLoading = false }: GameDetailsFormProps) {
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(GameSchema),
    defaultValues: {
      title: game.title,
      sport_type: game.sport_type,
      skill_level: game.skill_level,
      date: game.date,
      time: game.time,
      duration: game.duration,
      location: game.location,
      address: game.address,
      max_players: game.max_players,
      price_per_player: game.price_per_player,
      equipment: game.equipment,
      description: game.description,
      rules: game.rules
    }
  });

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <Input
        label="Event Title"
        type="text"
        error={errors.title?.message}
        placeholder="Enter event title"
        {...register('title')}
      />

      <div className="grid grid-cols-2 gap-4">
        <Input
          label="Sport Type"
          type="text"
          error={errors.sport_type?.message}
          placeholder="e.g., Football, Basketball"
          {...register('sport_type')}
        />

        <Input
          label="Skill Level"
          type="text"
          error={errors.skill_level?.message}
          placeholder="e.g., Beginner, Intermediate, Advanced"
          {...register('skill_level')}
        />
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Input
          label="Date"
          type="date"
          error={errors.date?.message}
          {...register('date')}
        />

        <Input
          label="Time"
          type="time"
          error={errors.time?.message}
          {...register('time')}
        />

        <Input
          label="Duration (minutes)"
          type="number"
          min="30"
          max="240"
          error={errors.duration?.message}
          placeholder="e.g., 90"
          {...register('duration', { valueAsNumber: true })}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Input
          label="Location Name"
          type="text"
          error={errors.location?.message}
          placeholder="e.g., Central Park Field"
          {...register('location')}
        />

        <Input
          label="Address"
          type="text"
          error={errors.address?.message}
          placeholder="Enter full address"
          {...register('address')}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Input
          label="Maximum Players"
          type="number"
          min="2"
          max="30"
          error={errors.max_players?.message}
          placeholder="e.g., 10"
          {...register('max_players', { valueAsNumber: true })}
        />

        <Input
          label="Price per Player"
          type="number"
          min="0"
          step="0.01"
          error={errors.price_per_player?.message}
          placeholder="e.g., 15.00"
          {...register('price_per_player', { valueAsNumber: true })}
        />
      </div>

      <Input
        label="Required Equipment"
        type="text"
        error={errors.equipment?.message}
        placeholder="e.g., Football boots, shin guards"
        {...register('equipment')}
      />

      <Input
        label="Description"
        type="text"
        error={errors.description?.message}
        placeholder="Provide details about the game event..."
        {...register('description')}
      />

      <Input
        label="Rules and Guidelines"
        type="text"
        error={errors.rules?.message}
        placeholder="List any specific rules or guidelines..."
        {...register('rules')}
      />

      <div className="flex justify-end space-x-4">
        <Button
          type="button"
          variant="outline"
          onClick={() => window.history.back()}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          isLoading={isLoading}
        >
          {game.id ? 'Update Game Details' : 'Create Game'}
        </Button>
      </div>
    </form>
  );
}