import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '../ui/Button';
import { Input } from '../ui/Input';
import { AlertTriangle } from 'lucide-react';

const cancelSchema = z.object({
  reason: z.string().min(10, 'Please provide a detailed reason for cancellation')
});

interface CancelGameModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (reason: string) => Promise<void>;
  isLoading?: boolean;
}

export function CancelGameModal({ 
  isOpen, 
  onClose, 
  onConfirm,
  isLoading = false 
}: CancelGameModalProps) {
  const { register, handleSubmit, formState: { errors } } = useForm({
    resolver: zodResolver(cancelSchema)
  });

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg max-w-md w-full mx-4 p-6">
        <div className="flex items-center space-x-2 text-red-600 mb-4">
          <AlertTriangle className="w-6 h-6" />
          <h3 className="text-lg font-semibold">Cancel Game</h3>
        </div>

        <form onSubmit={handleSubmit(data => onConfirm(data.reason))}>
          <div className="space-y-4">
            <p className="text-gray-600">
              Please provide a reason for cancelling this game. All participants will be notified.
            </p>

            <Input
              label="Cancellation Reason"
              type="text"
              placeholder="Enter reason for cancellation"
              error={errors.reason?.message}
              {...register('reason')}
            />

            <div className="flex justify-end space-x-2 mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
                disabled={isLoading}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                isLoading={isLoading}
                className="bg-red-600 hover:bg-red-700"
              >
                Confirm Cancellation
              </Button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}