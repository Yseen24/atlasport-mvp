import React from 'react';
import { useAuthStore } from '../../store/authStore';
import { Button } from '../ui/Button';
import { Bell, BellOff, CheckCircle, XCircle } from 'lucide-react';
import type { EventParticipant, EventReminder } from '../../types/event';

interface EventActionsProps {
  gameId: string;
  participant?: EventParticipant;
  reminder?: EventReminder;
  onUpdateStatus: (status: 'CONFIRMED' | 'DECLINED' | 'LEFT') => Promise<void>;
  onToggleReady: () => Promise<void>;
  onSetReminder: (time: string) => Promise<void>;
}

export function EventActions({
  gameId,
  participant,
  reminder,
  onUpdateStatus,
  onToggleReady,
  onSetReminder
}: EventActionsProps) {
  const { user } = useAuthStore();
  const [isSettingReminder, setIsSettingReminder] = React.useState(false);

  if (!user || !participant) return null;

  const handleSetReminder = async (time: string) => {
    try {
      await onSetReminder(time);
    } catch (err) {
      console.error('Error setting reminder:', err);
    } finally {
      setIsSettingReminder(false);
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Your Status</h3>
        <div className="flex items-center gap-2">
          {participant.status === 'CONFIRMED' ? (
            <span className="inline-flex items-center text-sm text-green-600">
              <CheckCircle className="w-4 h-4 mr-1" />
              Confirmed
            </span>
          ) : participant.status === 'DECLINED' ? (
            <span className="inline-flex items-center text-sm text-red-600">
              <XCircle className="w-4 h-4 mr-1" />
              Declined
            </span>
          ) : (
            <span className="text-sm text-gray-600">Pending</span>
          )}
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <Button
          variant="outline"
          onClick={() => onUpdateStatus('CONFIRMED')}
          disabled={participant.status === 'CONFIRMED'}
        >
          Confirm Attendance
        </Button>
        <Button
          variant="outline"
          onClick={() => onUpdateStatus('DECLINED')}
          disabled={participant.status === 'DECLINED'}
        >
          Decline
        </Button>
        <Button
          variant={participant.isReady ? 'primary' : 'outline'}
          onClick={onToggleReady}
        >
          {participant.isReady ? 'Ready' : 'Mark as Ready'}
        </Button>
      </div>

      <div className="border-t border-gray-200 pt-4">
        <h4 className="text-sm font-medium text-gray-900 mb-2">Reminder</h4>
        {isSettingReminder ? (
          <div className="space-y-2">
            <input
              type="datetime-local"
              className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
              onChange={(e) => handleSetReminder(e.target.value)}
            />
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsSettingReminder(false)}
            >
              Cancel
            </Button>
          </div>
        ) : (
          <Button
            variant="outline"
            onClick={() => setIsSettingReminder(true)}
            className="w-full"
          >
            {reminder?.isEnabled ? (
              <>
                <BellOff className="w-4 h-4 mr-2" />
                Remove Reminder
              </>
            ) : (
              <>
                <Bell className="w-4 h-4 mr-2" />
                Set Reminder
              </>
            )}
          </Button>
        )}
      </div>
    </div>
  );
}