import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useGameDetails } from '../../hooks/useGameDetails';
import { useGameManagement } from '../../hooks/useGameManagement';
import { useEventGroup } from '../../hooks/useEventGroup';
import { useAuthStore } from '../../store/authStore';
import { GameManagementLayout } from './GameManagementLayout';
import { GameDetailsForm } from './GameDetailsForm';
import { ParticipantManagement } from './ParticipantManagement';
import { CancelGameModal } from './CancelGameModal';
import { Button } from '../ui/Button';
import { Alert } from '../ui/Alert';
import { Settings, Users, AlertTriangle } from 'lucide-react';
import { toast } from 'react-hot-toast';

export function GameManagement() {
  const { gameId } = useParams<{ gameId: string }>();
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [showCancelModal, setShowCancelModal] = useState(false);

  const { game, isLoading: isLoadingGame, error: gameError } = useGameDetails(gameId);
  const { participants, playerCount } = useEventGroup(gameId!);
  const { 
    updateGameDetails,
    cancelGame,
    removeParticipant,
    updateParticipantStatus,
    isLoading,
    error: managementError 
  } = useGameManagement(gameId!);

  // Verify authorization
  React.useEffect(() => {
    if (!isLoadingGame && game && user) {
      if (user.id !== game.organizer_id) {
        navigate('/unauthorized');
      }
    }
  }, [game, user, isLoadingGame, navigate]);

  if (isLoadingGame) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-gray-600">Loading game details...</div>
      </div>
    );
  }

  if (gameError || !game) {
    return (
      <div className="max-w-4xl mx-auto">
        <Alert
          type="error"
          message={gameError || 'Game not found'}
        />
        <Button
          onClick={() => navigate('/organizer/dashboard')}
          className="mt-4"
        >
          Back to Dashboard
        </Button>
      </div>
    );
  }

  const handleUpdateGame = async (data: any) => {
    try {
      const { error: updateError } = await updateGameDetails(data);
      if (updateError) throw new Error(updateError);
      toast.success('Game details updated successfully');
    } catch (err) {
      toast.error('Failed to update game details');
    }
  };

  const handleCancelGame = async (reason: string) => {
    try {
      const { error: cancelError } = await cancelGame(reason);
      if (cancelError) throw new Error(cancelError);
      toast.success('Game cancelled successfully');
      setShowCancelModal(false);
      navigate('/organizer/dashboard');
    } catch (err) {
      toast.error('Failed to cancel game');
    }
  };

  return (
    <GameManagementLayout game={game} error={managementError}>
      {/* Game Details Section */}
      <div className="space-y-4">
        <h2 className="text-lg font-semibold text-gray-900 flex items-center">
          <Settings className="w-5 h-5 mr-2" />
          Game Details
        </h2>
        <GameDetailsForm
          game={game}
          onSubmit={handleUpdateGame}
          isLoading={isLoading}
        />
      </div>

      {/* Participants Section */}
      <div className="space-y-4">
        <h2 className="text-lg font-semibold text-gray-900 flex items-center">
          <Users className="w-5 h-5 mr-2" />
          Players ({playerCount}/{game.max_players})
        </h2>
        <ParticipantManagement
          participants={participants}
          organizerId={game.organizer_id}
          onRemoveParticipant={removeParticipant}
          onUpdateStatus={updateParticipantStatus}
          isLoading={isLoading}
        />
      </div>

      {/* Game Actions */}
      <div className="space-y-4">
        <h2 className="text-lg font-semibold text-gray-900 flex items-center">
          <AlertTriangle className="w-5 h-5 mr-2" />
          Game Actions
        </h2>
        <Button
          variant="outline"
          className="text-red-600 hover:text-red-700 hover:bg-red-50"
          onClick={() => setShowCancelModal(true)}
          disabled={isLoading || game.status === 'CANCELLED'}
        >
          Cancel Game
        </Button>
      </div>

      {/* Cancel Game Modal */}
      <CancelGameModal
        isOpen={showCancelModal}
        onClose={() => setShowCancelModal(false)}
        onConfirm={handleCancelGame}
        isLoading={isLoading}
      />
    </GameManagementLayout>
  );
}