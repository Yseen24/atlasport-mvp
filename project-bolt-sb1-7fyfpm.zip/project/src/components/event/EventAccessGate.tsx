import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { useEventAccess } from '../../hooks/useEventAccess';
import { Alert } from '../ui/Alert';
import { Button } from '../ui/Button';
import { Lock } from 'lucide-react';

interface EventAccessGateProps {
  gameId: string;
  children: React.ReactNode;
}

export function EventAccessGate({ gameId, children }: EventAccessGateProps) {
  const location = useLocation();
  const { user } = useAuthStore();
  const { hasAccess, isLoading, error } = useEventAccess(gameId, user?.id);

  if (!user) {
    return (
      <Navigate 
        to="/login" 
        state={{ from: location }}
        replace 
      />
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-gray-600">Verifying access...</div>
      </div>
    );
  }

  if (error) {
    return (
      <Alert
        type="error"
        message={error}
      />
    );
  }

  if (!hasAccess) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[400px] space-y-4">
        <Lock className="w-12 h-12 text-gray-400" />
        <h2 className="text-xl font-semibold text-gray-900">Access Required</h2>
        <p className="text-gray-600 text-center max-w-md">
          You need to join this game to access the group chat.
        </p>
        <Button
          onClick={() => window.history.back()}
        >
          Back to Game Details
        </Button>
      </div>
    );
  }

  return <>{children}</>;
}