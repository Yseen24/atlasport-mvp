import React from 'react';
import { cn } from '../../lib/utils/form';
import { AlertCircle, CheckCircle, Info } from 'lucide-react';

interface AlertProps {
  type: 'error' | 'success' | 'info';
  message: string;
  className?: string;
}

const icons = {
  error: AlertCircle,
  success: CheckCircle,
  info: Info
};

const styles = {
  error: 'bg-red-50 border-red-200 text-red-600',
  success: 'bg-green-50 border-green-200 text-green-600',
  info: 'bg-blue-50 border-blue-200 text-blue-600'
};

export function Alert({ type, message, className }: AlertProps) {
  const Icon = icons[type];
  
  return (
    <div
      role="alert"
      className={cn(
        'flex items-center gap-2 p-3 border rounded-md text-sm',
        styles[type],
        className
      )}
    >
      <Icon className="h-4 w-4 flex-shrink-0" />
      <span>{message}</span>
    </div>
  );
}