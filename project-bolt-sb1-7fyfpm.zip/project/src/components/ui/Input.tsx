import React from 'react';
import { cn } from '../../lib/utils/form';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
  helperText?: string;
  icon?: React.ReactNode;
}

export const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ label, error, helperText, icon, className, type = 'text', ...props }, ref) => {
    const id = React.useId();

    return (
      <div className="space-y-1">
        <label
          htmlFor={id}
          className="block text-sm font-medium text-gray-700"
        >
          {label}
        </label>
        <div className="relative">
          {icon && (
            <div className="absolute left-3 top-1/2 -translate-y-1/2">
              {icon}
            </div>
          )}
          <input
            id={id}
            ref={ref}
            type={type}
            className={cn(
              "w-full rounded-lg shadow-sm transition-colors",
              "focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500",
              icon ? "pl-10" : "pl-4",
              "pr-4 py-2",
              error 
                ? "border-red-300 focus:border-red-500 focus:ring-red-500" 
                : "border-gray-300",
              className
            )}
            aria-describedby={error ? `${id}-error` : helperText ? `${id}-helper` : undefined}
            {...props}
          />
        </div>
        {error && (
          <p 
            id={`${id}-error`}
            className="text-sm text-red-600"
          >
            {error}
          </p>
        )}
        {helperText && !error && (
          <p 
            id={`${id}-helper`}
            className="text-sm text-gray-500"
          >
            {helperText}
          </p>
        )}
      </div>
    );
  }
);

Input.displayName = 'Input';