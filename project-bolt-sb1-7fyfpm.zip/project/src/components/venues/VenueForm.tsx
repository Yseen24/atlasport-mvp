import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { VenueSchema } from '../../schemas/venue';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { MapPin, Clock, Phone } from 'lucide-react';
import type { VenueFormData, Sport_Type } from '../../types';

interface VenueFormProps {
  onSubmit: (data: VenueFormData) => Promise<void>;
  isSubmitting?: boolean;
}

interface VenueFormInputs {
  name: string;
  address: string;
  sports_supported: Record<Sport_Type, boolean>;
  facilities: Record<string, boolean>;
  openingTime: string;
  closingTime: string;
  contactPhone: string;
}

const SPORTS: Array<{ id: Sport_Type; label: string }> = [
];

const FACILITIES = [
  { id: 'changing_rooms', label: 'Changing Rooms' },
  { id: 'parking', label: 'Parking' },
  { id: 'lighting', label: 'Lighting' },
  { id: 'spectator_seating', label: 'Spectator Seating' },
  { id: 'shower', label: 'Shower' },
  { id: 'lockbox', label: 'Lockbox' }
] as const;

export function VenueForm({ onSubmit, isSubmitting = false }: VenueFormProps) {
  const { register, handleSubmit, formState: { errors }, reset } = useForm<VenueFormInputs>({
    resolver: zodResolver(VenueSchema),
    defaultValues: {
      sports_supported: SPORTS.reduce((acc, sport) => ({
        ...acc,
        [sport.id]: false
      }), {} as Record<Sport_Type, boolean>),
      facilities: FACILITIES.reduce((acc, facility) => ({
        ...acc,
        [facility.id]: false
      }), {} as Record<string, boolean>)
    }
  });

  const handleFormSubmit = async (data: VenueFormInputs) => {
    try {
      const formattedData: VenueFormData = {
        name: data.name.trim(),
        address: data.address.trim(),
        sports_supported: Object.entries(data.sports_supported)
          .filter(([_, value]) => value)
          .map(([key]) => key as Sport_Type),
        facilities: Object.entries(data.facilities)
          .filter(([_, value]) => value)
          .map(([key]) => key),
        openingTime: data.openingTime,
        closingTime: data.closingTime,
        contactPhone: data.contactPhone.trim()
      };

      await onSubmit(formattedData);
      reset();
    } catch (error) {
      console.error('Form submission error:', error);
    }
  };

  return (
    <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6">
      <Input
        label="Venue Name"
        placeholder="Enter venue name"
        error={errors.name?.message}
        icon={<MapPin className="w-5 h-5 text-gray-400" />}
        {...register('name')}
      />

      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700">
          Available Sports
        </label>
        <div className="grid grid-cols-2 gap-4">
          {SPORTS.map(({ id, label }) => (
            <label key={id} className="flex items-center space-x-2">
              <input
                type="checkbox"
                {...register(`sports_supported.${id}`)}
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-gray-700">{label}</span>
            </label>
          ))}
        </div>
        {errors.sports_supported && (
          <p className="text-sm text-red-600">Please select at least one sport</p>
        )}
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700">
          Address
        </label>
        <textarea
          {...register('address')}
          className="w-full rounded-lg border-gray-300 focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          rows={3}
          placeholder="Enter full address"
        />
        {errors.address && (
          <p className="text-sm text-red-600">{errors.address.message}</p>
        )}
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-medium text-gray-700">
          Available Facilities
        </label>
        <div className="grid grid-cols-2 gap-4">
          {FACILITIES.map(({ id, label }) => (
            <label key={id} className="flex items-center space-x-2">
              <input
                type="checkbox"
                {...register(`facilities.${id}`)}
                className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
              />
              <span className="text-gray-700">{label}</span>
            </label>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6">
        <Input
          label="Opening Time"
          type="time"
          error={errors.openingTime?.message}
          icon={<Clock className="w-5 h-5 text-gray-400" />}
          {...register('openingTime')}
        />
        <Input
          label="Closing Time"
          type="time"
          error={errors.closingTime?.message}
          icon={<Clock className="w-5 h-5 text-gray-400" />}
          {...register('closingTime')}
        />
      </div>

      <Input
        label="Contact Phone"
        type="tel"
        placeholder="+212606060606"
        error={errors.contactPhone?.message}
        icon={<Phone className="w-5 h-5 text-gray-400" />}
        {...register('contactPhone')}
      />

      <div className="flex justify-end space-x-4 pt-6">
        <Button
          type="button"
          variant="outline"
          onClick={() => reset()}
          disabled={isSubmitting}
        >
          Reset
        </Button>
        <Button
          type="submit"
          isLoading={isSubmitting}
        >
          Create Venue
        </Button>
      </div>
    </form>
  );
}