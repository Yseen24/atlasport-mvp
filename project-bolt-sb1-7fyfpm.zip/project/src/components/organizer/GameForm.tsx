import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { GameSchema } from '../../schemas/game';
import { useGameForm } from '../../hooks/useGameForm';
import { useAuthStore } from '../../store/authStore';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { Alert } from '../ui/Alert';
import { toast } from 'react-hot-toast';
import { Sport_Type } from '../../types';
import React from 'react';

type GameFormData = {
  title: string;
  sport_Type: Sport_Type;
  skill_Level: string;
  date: string;
  time: string;
  duration: number;
  venueId: string;
  maxPlayers: number;
  pricePerPlayer: number;
  description: string;
  rules: string;
};

export function GameForm() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { venues, isLoading, error, fetchVenues, createGame } = useGameForm();
  const [status, setStatus] = React.useState<{
    type: 'success' | 'error';
    message: string;
  } | null>(null);

  const { 
    register, 
    handleSubmit, 
    formState: { errors },
    reset 
  } = useForm<GameFormData>({
    resolver: zodResolver(GameSchema)
  });

  React.useEffect(() => {
    fetchVenues();
  }, []);

  const onSubmit = async (data: GameFormData) => {
    if (!user) return;

    try {
      if (user.role === 'ORGANIZER' && user.organizer_status !== 'APPROVED') {
        setStatus({
          type: 'error',
          message: 'Your account status is currently pending approval. Please wait until your status is updated before creating a new game. We appreciate your patience!'
        });
        return;
      }

      const { data: gameData, error: gameError } = await createGame({
        ...data,
        organizerId: user.id,
        maxPlayers: Number(data.maxPlayers),
        pricePerPlayer: Number(data.pricePerPlayer),
        duration: Number(data.duration)
      });

      if (gameError) {
        if (typeof gameError === 'string' && gameError.includes('Only approved organizers')) {
          setStatus({
            type: 'error',
            message: 'Your account status is currently pending approval. Please wait until your status is updated before creating a new game. We appreciate your patience!'
          });
          return;
        }
      
        setStatus({
          type: 'error',
          message: typeof gameError === 'string' ? gameError : gameError.message || 'An error occurred'
        });
        return;
      }

      toast.success('Game created successfully!');
      reset();

      if (gameData?.id) {
        navigate(`/games/${gameData.id}`, {
          state: { 
            message: 'Game created successfully! You can now manage your game details.',
            isNew: true
          }
        });
      }
    } catch (err) {
      setStatus({
        type: 'error',
        message: 'Failed to create game. Please try again.'
      });
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {(status || error) && (
    <Alert
      type={status?.type || 'error'}
      message={status?.message || (error ? String(error) : 'An error occurred')}
      className="mb-6"
    />
  )}

      <Input
        label="Event Title"
        type="text"
        error={errors.title?.message}
        placeholder="Enter event title"
        {...register('title')}
      />

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Sport Type
          </label>
          <select
            {...register('sport_Type')}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            <option value="">Select a sport</option>
            <option value="Football">Football</option>
            <option value="Basketball">Basketball</option>
            <option value="Volleyball">Volleyball</option>
          </select>
          {errors.sport_Type && (
            <p className="mt-1 text-sm text-red-600">{errors.sport_Type.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Skill Level
          </label>
          <select
            {...register('skill_Level')}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            <option value="">Select skill level</option>
            <option value="beginner">Beginner</option>
            <option value="intermediate">Intermediate</option>
            <option value="advanced">Advanced</option>
            <option value="all">All Levels</option>
          </select>
          {errors.skill_Level && (
            <p className="mt-1 text-sm text-red-600">{errors.skill_Level.message}</p>
          )}
        </div>
      </div>

      <div className="grid grid-cols-3 gap-4">
        <Input
          label="Date"
          type="date"
          error={errors.date?.message}
          {...register('date')}
        />
        <Input
          label="Time"
          type="time"
          error={errors.time?.message}
          {...register('time')}
        />
        <Input
          label="Duration (minutes)"
          type="number"
          min="30"
          max="240"
          error={errors.duration?.message}
          placeholder="e.g., 90"
          {...register('duration', { valueAsNumber: true })}
        />
      </div>
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Venue
        </label>
        <select
          {...register('venueId')}
          className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
        >
          <option value="">Select a venue</option>
          {venues?.map((venue) => (
            <option key={venue.id} value={venue.id}>
              {venue.name}
            </option>
          ))}
        </select>
        {errors.venueId && (
          <p className="mt-1 text-sm text-red-600">{errors.venueId.message}</p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Input
          label="Maximum Players"
          type="number"
          min="2"
          max="30"
          error={errors.maxPlayers?.message}
          placeholder="e.g., 10"
          {...register('maxPlayers', { valueAsNumber: true })}
        />
        <Input
          label="Price per Player"
          type="number"
          min="0"
          step="0.01"
          error={errors.pricePerPlayer?.message}
          placeholder="e.g., 15.00"
          {...register('pricePerPlayer', { valueAsNumber: true })}
        />
      </div>

      <Input
        label="Description"
        type="text"
        error={errors.description?.message}
        placeholder="Provide details about the game event..."
        {...register('description')}
      />

      <Input
        label="Rules and Guidelines"
        type="text"
        error={errors.rules?.message}
        placeholder="List any specific rules or guidelines..."
        {...register('rules')}
      />

      <Button
        type="submit"
        isLoading={isLoading}
        fullWidth
      >
        Create Game
      </Button>
    </form>
  );
}