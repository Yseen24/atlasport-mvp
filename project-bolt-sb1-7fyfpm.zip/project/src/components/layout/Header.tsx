import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { useAuth } from '../../hooks/useAuth';
import { Trophy, UserCircle } from 'lucide-react';

export function Header() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { signOut } = useAuth();

  const handleSignOut = async () => {
    await signOut();
    navigate('/login');
  };

  return (
    <header className="bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex">
            <Link to="/" className="flex items-center">
              <Trophy className="h-8 w-8 text-blue-600" />
              <span className="ml-2 text-xl font-bold text-gray-900">Atlasport</span>
            </Link>
          </div>

          <nav className="flex items-center space-x-4">
            <Link to="/games" className="text-gray-600 hover:text-gray-900">
              Games
            </Link>
            {user ? (
              <>
                <Link 
                  to={`/${user.role.toLowerCase()}/dashboard`}
                  className="text-gray-600 hover:text-gray-900"
                >
                  Dashboard
                </Link>
                <Link
                  to="/profile"
                  className="flex items-center text-gray-600 hover:text-gray-900"
                >
                  <UserCircle className="w-5 h-5 mr-1" />
                  <span>Profile</span>
                </Link>
                <button 
                  onClick={handleSignOut}
                  className="text-gray-600 hover:text-gray-900"
                >
                  Sign Out
                </button>
              </>
            ) : (
              <>
                <Link 
                  to="/login"
                  className="text-gray-600 hover:text-gray-900"
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700"
                >
                  Register
                </Link>
              </>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
}