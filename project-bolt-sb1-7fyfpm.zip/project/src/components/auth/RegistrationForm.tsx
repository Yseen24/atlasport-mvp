import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { RegisterSchema } from '../../schemas/auth';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { Alert } from '../ui/Alert';
import { Link } from 'react-router-dom';
import { UserPlus, User, Mail, Phone, Shield } from 'lucide-react';
import type { RegisterFormData } from '../../types';

interface RegistrationFormProps {
  onSubmit: (data: RegisterFormData) => Promise<void>;
  error?: string | null;
  isSubmitting?: boolean;
}

export function RegistrationForm({ onSubmit, error, isSubmitting = false }: RegistrationFormProps) {
  const { 
    register, 
    handleSubmit, 
    formState: { errors },
    watch,
    reset
  } = useForm<RegisterFormData>({
    resolver: zodResolver(RegisterSchema)
  });

  const handleFormSubmit = async (data: RegisterFormData) => {
    try {
      await onSubmit(data);
      reset();
    } catch (err) {
      console.error('Form submission error:', err);
    }
  };

  return (
    <div className="space-y-6">
      {error && (
        <Alert type="error" message={error} />
      )}

      <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-5">
        <div className="space-y-4">
          <div className="relative">
            <Input
              label="Full Name"
              type="text"
              placeholder="Your name"
              error={errors.name?.message}
              icon={<User className="w-5 h-5 text-gray-400" />}
              {...register('name')}
            />
          </div>

          <div className="relative">
            <Input
              label="Email"
              type="email"
              placeholder="you@example.com"
              error={errors.email?.message}
              icon={<Mail className="w-5 h-5 text-gray-400" />}
              {...register('email')}
            />
          </div>

          <div className="relative">
            <Input
              label="Phone Number"
              type="tel"
              placeholder="Phone number"
              error={errors.phone?.message}
              icon={<Phone className="w-5 h-5 text-gray-400" />}
              {...register('phone')}
            />
          </div>

          <div className="space-y-1">
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Role
            </label>
            <div className="relative">
              <Shield className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <select
                {...register('role')}
                className="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 bg-white shadow-sm transition-colors"
              >
                <option value="Player">Player</option>
                <option value="Organizer">Organizer</option>
              </select>
            </div>
            {errors.role && (
              <p className="text-sm text-red-600 mt-1">{errors.role.message}</p>
            )}
          </div>

          <div className="relative">
            <Input
              label="Password"
              type="password"
              placeholder="••••••"
              error={errors.password?.message}
              helperText="Must be at least 6 characters"
              {...register('password')}
            />
          </div>

          <div className="relative">
            <Input
              label="Confirm Password"
              type="password"
              placeholder="••••••"
              error={errors.confirmPassword?.message}
              {...register('confirmPassword', {
                validate: value => value === watch('password') || "Passwords don't match"
              })}
            />
          </div>
        </div>

        <Button
          type="submit"
          isLoading={isSubmitting}
          fullWidth
          className="bg-gradient-to-r from-emerald-600 to-emerald-500 hover:from-emerald-700 hover:to-emerald-600 text-white font-medium py-2.5 rounded-lg shadow-sm transition-all duration-150 flex items-center justify-center"
        >
          {isSubmitting ? (
            'Creating account...'
          ) : (
            <>
              <UserPlus className="w-5 h-5 mr-2" />
              Create Account
            </>
          )}
        </Button>
      </form>

      <div className="text-center text-sm">
        <span className="text-gray-600">Already have an account?</span>{' '}
        <Link 
          to="/login" 
          className="text-emerald-600 hover:text-emerald-700 font-medium"
        >
          Sign in
        </Link>
      </div>
    </div>
  );
}