import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { RegisterSchema } from '../../schemas/auth';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';
import { Alert } from '../ui/Alert';
import { Link } from 'react-router-dom';
import type { RegisterFormData } from '../../types';

interface RegisterFormProps {
  onSubmit: (data: RegisterFormData) => Promise<void>;
  error?: string | null;
  isSubmitting?: boolean;
}

export function RegisterForm({ onSubmit, error, isSubmitting = false }: RegisterFormProps) {
  const { 
    register, 
    handleSubmit, 
    formState: { errors },
    reset,
    watch
  } = useForm<RegisterFormData>({
    resolver: zodResolver(RegisterSchema),
    defaultValues: {
      role: 'Player'
    }
  });

  const handleFormSubmit = async (data: RegisterFormData) => {
    try {
      await onSubmit(data);
      reset();
    } catch (err) {
      console.error('Form submission error:', err);
    }
  };

  // Watch password for confirmation matching
  const password = watch('password');

  return (
    <div className="space-y-6">
      {error && (
        <Alert type="error" message={error} />
      )}

      <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-4" noValidate>
        <Input
          label="Full Name"
          type="text"
          placeholder="John Doe"
          error={errors.name?.message}
          helperText="Enter your legal name as it appears on official documents"
          {...register('name')}
        />

        <Input
          label="Email"
          type="email"
          placeholder="you@example.com"
          error={errors.email?.message}
          {...register('email')}
        />

        <Input
          label="Phone Number"
          type="tel"
          placeholder="+1234567890"
          error={errors.phone?.message}
          helperText="Include country code (e.g., +1 for US)"
          {...register('phone')}
        />

        <div className="space-y-1">
          <label className="block text-sm font-medium text-gray-700">
            Role
          </label>
          <select
            {...register('role')}
            className="w-full rounded-md border-gray-300 shadow-sm focus:border-blue-500 focus:ring-blue-500"
          >
            <option value="Player">Player</option>
            <option value="Organizer">Organizer</option>
          </select>
          {errors.role && (
            <p className="text-sm text-red-600">{errors.role.message}</p>
          )}
        </div>

        <Input
          label="Password"
          type="password"
          placeholder="••••••••"
          error={errors.password?.message}
          helperText="Must be at least 8 characters with 1 uppercase, 1 lowercase, 1 number, and 1 special character"
          {...register('password')}
        />

        <Input
          label="Confirm Password"
          type="password"
          placeholder="••••••••"
          error={errors.confirmPassword?.message}
          {...register('confirmPassword', {
            validate: value => value === password || "Passwords don't match"
          })}
        />

        <Button
          type="submit"
          isLoading={isSubmitting}
          fullWidth
        >
          {isSubmitting ? 'Creating account...' : 'Create Account'}
        </Button>
      </form>

      <div className="text-center text-sm">
        <span className="text-gray-600">Already have an account?</span>{' '}
        <Link 
          to="/login" 
          className="text-blue-600 hover:text-blue-700 font-medium"
        >
          Sign in
        </Link>
      </div>
    </div>
  );
}