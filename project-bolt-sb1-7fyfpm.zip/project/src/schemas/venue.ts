import { z } from 'zod';

export const VenueSchema = z.object({
  name: z.string().min(1, 'Venue name is required'),
  address: z.string().min(1, 'Address is required'),
  sports: z.record(z.boolean()).refine(
    (sports) => Object.values(sports).some((selected) => selected),
    'Please select at least one sport'
  ),
  facilities: z.record(z.boolean()).optional(),
  openingTime: z.string().min(1, 'Opening time is required'),
  closingTime: z.string().min(1, 'Closing time is required'),
  contactPhone: z.string()
    .min(1, 'Contact phone is required')
    .regex(
      /^\+?[1-9]\d{1,14}$/, 
      'Please enter a valid phone number'
    )
});