import { z } from 'zod';

export const GameSchema = z.object({
  title: z.string()
    .min(1, 'Title is required')
    .max(100, 'Title must not exceed 100 characters')
    .trim(),
  
    sport_Type: z.enum(['Football', 'Basketball', 'Volleyball'], {
      errorMap: () => ({ message: 'Please select a valid sport type' })
    }),
  
  Skill_Level: z.enum(['beginner', 'intermediate', 'advanced', 'all'], {
    errorMap: () => ({ message: 'Please select a valid skill level' })
  }),
  
  date: z.string()
    .min(1, 'Date is required')
    .refine((date) => new Date(date) > new Date(), {
      message: 'Date must be in the future'
    }),
  
  time: z.string().min(1, 'Time is required'),
  
  duration: z.number()
    .int('Duration must be a whole number')
    .min(60, 'Duration must be at least 60 minutes')
    .max(120, 'Duration cannot exceed 2 hours'),
  
  venueId: z.string().uuid('Invalid venue selected'),
  
  maxPlayers: z.number()
    .int('Number of players must be a whole number')
    .min(10, 'Minimum 10 players required')
    .max(15, 'Maximum 15 players allowed'),
  
  pricePerPlayer: z.number()
    .min(0, 'Price must be 0 or greater')
    .max(1000, 'Price cannot exceed 1000')
    .multipleOf(0.01, 'Price must have at most 2 decimal places'),
  
  description: z.string()
    .min(1, 'Description is required')
    .max(1000, 'Description must not exceed 1000 characters')
    .trim(),
  
  rules: z.string()
    .max(1000, 'Rules must not exceed 1000 characters')
    .trim()
    .optional()
    .nullable()
    .default('')
});

export type GameFormSchema = z.infer<typeof GameSchema>;