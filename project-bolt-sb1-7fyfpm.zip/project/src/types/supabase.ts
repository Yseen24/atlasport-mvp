export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          name: string
          role: 'Player' | 'Organizer' | 'Admin'
          phone: string
          created_at: string
          organizer_status: string
        }
        Insert: {
          id: string
          email: string
          name: string
          role?: 'Player' | 'Organizer' | 'Admin'
          phone: string
          created_at?: string
          organizer_status?: string
        }
        Update: {
          id?: string
          email?: string
          name?: string
          role?: 'Player' | 'Organizer' | 'Admin'
          phone?: string
          created_at?: string
          organizer_status?: string
        }
      }
      venues: {
        Row: {
          id: string
          name: string
          address: string
          sports_supported: string[]
          status: string
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          address: string
          sports_supported: string[]
          status?: string
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          address?: string
          sports_supported?: string[]
          status?: string
          created_at?: string
        }
      }
      games: {
        Row: {
          id: string
          sport_type: string
          skill_Level: string
          date: string
          time: string
          duration: string
          venue_id: string
          organizer_id: string
          max_players: number
          current_players: number
          price_per_player: number
          description: string
          rules: string
          status: 'UPCOMING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED'
          created_at: string
        }
        Insert: {
          id?: string
          sport_type: string
          skill_Level: string
          time: string
          duration: string
          venue_id: string
          organizer_id: string
          max_players: number
          current_players?: number
          price_per_player: number
          description: string
          rules: string
          status?: 'UPCOMING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED'
          created_at?: string
        }
        Update: {
          id?: string
          sport_type?: string
          skill_Level?: string
          date?: string
          time?: string
          duration?: string
          venue_id?: string
          organizer_id?: string
          max_players?: number
          current_players?: number
          price_per_player?: number
          description?: string
          rules?: string
          status?: 'UPCOMING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED'
          created_at?: string
        }
      }
      game_participants: {
        Row: {
          id: string
          game_id: string
          player_id: string
          status: 'CONFIRMED' | 'CANCELLED'
          joined_at: string
        }
        Insert: {
          id?: string
          game_id: string
          player_id: string
          status?: 'CONFIRMED' | 'CANCELLED'
          joined_at?: string
        }
        Update: {
          id?: string
          game_id?: string
          player_id?: string
          status?: 'CONFIRMED' | 'CANCELLED'
          joined_at?: string
        }
      }
      messages: {
        Row: {
          id: string
          game_id: string
          user_id: string
          content: string
          created_at: string
        }
        Insert: {
          id?: string
          game_id: string
          user_id: string
          content: string
          created_at?: string
        }
        Update: {
          id?: string
          game_id?: string
          user_id?: string
          content?: string
          created_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}