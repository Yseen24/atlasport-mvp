export type ParticipantStatus = 'PENDING' | 'CONFIRMED' | 'DECLINED' | 'LEFT';
export type MessageType = 'CHAT' | 'ANNOUNCEMENT';

export interface EventParticipant {
  id: string;
  gameId: string;
  userId: string;
  status: ParticipantStatus;
  isReady: boolean;
  joinedAt: string;
  user: {
    id: string;
    name: string;
    email: string;
  };
}

export interface EventMessage {
  id: string;
  gameId: string;
  userId: string;
  content: string;
  type: MessageType;
  createdAt: string;
  user: {
    id: string;
    name: string;
  };
}

export interface EventReminder {
  id: string;
  gameId: string;
  userId: string;
  reminderTime: string;
  isEnabled: boolean;
  createdAt: string;
}