// Enums
export enum Sport_Type {
  Football = 'Football',
  Basketball = 'Basketball',
  Volleyball = 'Volleyball'
}

export type UserRole = 'PLAYER' | 'ORGANIZER' | 'ADMIN';
export type OrganizerStatus = 'NOT_APPLIED' | 'PENDING' | 'APPROVED';
export type GameStatus = 'UPCOMING' | 'IN_PROGRESS' | 'COMPLETED' | 'CANCELLED';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  phone: string;
  profile_picture?: string;
  created_at: string;
  organizer_status: OrganizerStatus;
}

export interface Game {
  id: string;
  title: string;
  sport_type: Sport_Type;=
  skill_level: string;
  date: string;
  time: string;
  duration: number;
  venue_id: string;
  venue?: Venue;         // access venue details
  organizer_id: string;
  organizer?: User;      // access organizer details
  max_players: number;
  current_players: number;
  status: GameStatus;
  created_at: string;
  price_per_player: number;
  description: string;
  rules: string;
}

export interface RegisterFormData {
  name: string;
  email: string;
  password: string;
  confirmPassword: string;
  role: 'Player' | 'Organizer';
  phone: string;
}


export interface Venue {
  id: string;
  name: string;
  address: string;
  sports_supported: string[];
  facilities?: string[];
  opening_time: string;
  closing_time: string;
  contact_phone: string;
  status: string;
  created_at: string;
}

export interface VenueFormData {
  name: string;
  address: string;
  sports_supported: Sport_Type[];
  facilities?: string[];
  openingTime: string;
  closingTime: string;
  contactPhone: string;
}

